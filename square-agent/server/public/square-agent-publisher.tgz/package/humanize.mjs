/**
 * 拟人化模块 - 让自动化操作更像真人
 * 
 * 核心改进：
 * 1. 随机延迟抖动（±30%）
 * 2. 随机点击偏移（±3像素）
 * 3. 打字速度波动（100-180 WPM）
 * 4. 夜间静默（23:00-08:00不操作）
 */

// ========== 随机工具 ==========

function rand(min, max) {
  return min + Math.random() * (max - min);
}

function randInt(min, max) {
  return Math.floor(rand(min, max + 1));
}

function gaussRand(mean = 0, stddev = 1) {
  const u = 1 - Math.random();
  const v = Math.random();
  const z = Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  return z * stddev + mean;
}

// ========== 时间控制 ==========

/**
 * 判断是否在静默时段
 * @param {string} timezone - IANA timezone
 * @returns {{ quiet: boolean, reason?: string }}
 */
export function checkQuietHours(timezone = 'Asia/Shanghai') {
  const now = new Date();
  const hour = parseInt(now.toLocaleString('en-US', { hour: 'numeric', hour12: false, timeZone: timezone }));
  
  if (hour >= 23 || hour < 8) {
    return { quiet: true, reason: `静默时段(${hour}:00)，跳过操作` };
  }
  return { quiet: false };
}

/**
 * 带抖动的延迟
 * 基础延迟 ± 30% 随机波动
 * @param {number} baseMs - 基础延迟（ms）
 * @returns {number} 实际延迟
 */
export function humanDelay(baseMs) {
  let jitter = baseMs * rand(-0.3, 0.3);
  if (Math.random() < 0.1) {
    jitter += rand(1000, 3000);
  }
  return Math.max(100, Math.round(baseMs + jitter));
}

/**
 * 批量操作的间隔
 * @param {number} index - 当前操作序号
 * @param {number} total - 总操作数
 * @returns {number} 间隔ms
 */
export function batchInterval(index, total) {
  let base = rand(3000, 8000);
  if (index < 3) base *= 1.5;
  if (index > 3 && index < total - 3) base *= 0.8;
  if (index >= total - 3) base *= 1.3;
  if (Math.random() < 0.05) base += rand(15000, 45000);
  return Math.round(base);
}

// ========== 坐标偏移 ==========

/**
 * 随机偏移点击位置
 * @param {number} x
 * @param {number} y
 * @param {number} maxOffset
 * @returns {{x, y}}
 */
export function jitterCoords(x, y, maxOffset = 3) {
  return {
    x: Math.round(x + gaussRand(0, maxOffset * 0.5)),
    y: Math.round(y + gaussRand(0, maxOffset * 0.5))
  };
}

// ========== 打字模拟 ==========

/**
 * 模拟人类打字节奏
 * @param {string} text
 * @returns {Array<number>} 每个字符的间隔时间（ms）
 */
export function typingRhythm(text) {
  const intervals = [];
  const baseCpm = rand(300, 600);
  const baseInterval = 60000 / baseCpm;

  for (let i = 0; i < text.length; i++) {
    let delay = baseInterval;
    if (i > 0 && '，。！？、；：'.includes(text[i - 1])) {
      delay *= rand(2, 4);
    }
    if (text[i] === '\n') {
      delay *= rand(3, 6);
    }
    if (text[i] === ' ') {
      delay *= 0.7;
    }
    delay *= rand(0.6, 1.4);
    intervals.push(Math.max(20, Math.round(delay)));
  }

  return intervals;
}

// ========== 发布频率限制 ==========

const DAILY_LIMITS = {
  max_posts: 8,
  max_comments: 50,
  min_post_interval: 30 * 60 * 1000,
  max_posts_per_hour: 2,
};

export function checkPublishLimit(todayPosts = []) {
  const now = Date.now();
  const oneHourAgo = now - 3600000;
  const oneDayAgo = now - 86400000;

  const todayCount = todayPosts.filter(t => t > oneDayAgo).length;
  if (todayCount >= DAILY_LIMITS.max_posts) {
    return { allowed: false, reason: `今天已发${todayCount}条，达到日上限${DAILY_LIMITS.max_posts}` };
  }

  const hourCount = todayPosts.filter(t => t > oneHourAgo).length;
  if (hourCount >= DAILY_LIMITS.max_posts_per_hour) {
    return { allowed: false, reason: `过去1小时已发${hourCount}条，限制${DAILY_LIMITS.max_posts_per_hour}/小时` };
  }

  const lastPost = todayPosts[todayPosts.length - 1];
  if (lastPost && (now - lastPost) < DAILY_LIMITS.min_post_interval) {
    const waitMs = DAILY_LIMITS.min_post_interval - (now - lastPost);
    return { allowed: false, reason: `距上次发帖不到30分钟，需等${Math.round(waitMs / 60000)}分钟`, waitMs };
  }

  return { allowed: true };
}

export { DAILY_LIMITS };
