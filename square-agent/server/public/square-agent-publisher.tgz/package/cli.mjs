#!/usr/bin/env node
/**
 * SquareAgent CLI - 币安广场自动发布代理
 * 
 * 用法:
 *   square-agent login --key sk-xxxxx    # 绑定 API Key
 *   square-agent start                    # 启动代理（前台）
 *   square-agent start --daemon           # 后台运行
 *   square-agent status                   # 查看状态
 *   square-agent stop                     # 停止后台代理
 *   square-agent history [n]              # 查看最近 n 条执行记录（默认20）
 *   square-agent states                   # 查看任务执行统计
 *   square-agent setting [key] [value]    # 查看/修改配置
 *   square-agent analytics <sub>          # 运行数据分析
 */

import { execSync, spawn } from 'child_process';
import { readFileSync, writeFileSync, existsSync, mkdirSync, readdirSync } from 'fs';
import { join } from 'path';
import { homedir } from 'os';
import https from 'https';
import http from 'http';

const AGENT_DIR = join(homedir(), '.square-agent-publisher');
const CONFIG_FILE = join(AGENT_DIR, 'config.json');
const PID_FILE = join(AGENT_DIR, 'agent.pid');
const LOG_DIR = join(AGENT_DIR, 'logs');

const argv = process.argv.slice(2);
const command = argv[0] || 'help';
const cmdArgs = argv.slice(1);

// ========== 工具函数 ==========

function getConfig() {
  try {
    return JSON.parse(readFileSync(CONFIG_FILE, 'utf8'));
  } catch {
    return null;
  }
}

function saveConfig(config) {
  if (!existsSync(AGENT_DIR)) mkdirSync(AGENT_DIR, { recursive: true });
  writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
}

function getPid() {
  try {
    return parseInt(readFileSync(PID_FILE, 'utf8'));
  } catch {
    return null;
  }
}

function isRunning(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}

function ts() {
  return new Date().toLocaleString('zh-CN', { hour12: false });
}

function httpRequest(method, urlPath, body) {
  const config = getConfig();
  const baseUrl = (config?.serverUrl || 'http://127.0.0.1:5577').replace(/\/$/, '');
  const isLocal = baseUrl.startsWith('http://');
  const requester = isLocal ? http : https;

  return new Promise((resolve) => {
    const url = new URL(urlPath, baseUrl);
    const postData = body ? JSON.stringify(body) : null;
    const headers = {
      'Authorization': `Bearer ${config?.apiKey || ''}`,
    };
    if (postData) {
      headers['Content-Type'] = 'application/json';
      headers['Content-Length'] = Buffer.byteLength(postData);
    }

    const options = { method, headers, timeout: 10000 };
    const req = requester.request(url, options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        if (res.statusCode >= 200 && res.statusCode < 300) {
          resolve({ ok: true, data });
        } else {
          resolve({ ok: false, error: `HTTP ${res.statusCode}: ${data}` });
        }
      });
    });
    req.on('error', (e) => resolve({ ok: false, error: e.message }));
    req.on('timeout', () => { req.destroy(); resolve({ ok: false, error: '请求超时' }); });
    if (postData) req.write(postData);
    req.end();
  });
}

function checkDependencies() {
  let chrome = false, peekaboo = false;
  try { execSync('osascript -e \'tell application "Google Chrome" to return name\'', { timeout: 5000 }); chrome = true; } catch {}
  try { execSync('which peekaboo', { timeout: 5000 }); peekaboo = true; } catch {}
  return { chrome, peekaboo, ok: chrome && peekaboo };
}

// ========== 命令 ==========

async function cmdLogin() {
  const keyArg = cmdArgs.find(a => a.startsWith('--key='));
  const keyIdx = cmdArgs.indexOf('--key');
  const apiKey = keyArg ? keyArg.split('=')[1] : (keyIdx >= 0 ? cmdArgs[keyIdx + 1] : null);

  if (!apiKey) {
    console.error('❌ 用法: square-agent login --key sk-xxxxx');
    process.exit(1);
  }

  if (!apiKey.startsWith('sk-') && !apiKey.startsWith('bsq_')) {
    console.error('❌ API Key 格式错误，应以 sk- 或 bsq_ 开头');
    process.exit(1);
  }

  console.log('🔐 验证 API Key...');
  const result = await httpRequest('GET', `/api/agent/verify?key=${apiKey}`);

  if (!result.ok) {
    console.error('❌ API Key 验证失败:', result.error);
    process.exit(1);
  }

  const data = JSON.parse(result.data);
  saveConfig({
    apiKey,
    userId: data.user_id,
    plan: data.plan,
    serverUrl: data.server_url || 'http://127.0.0.1:5577',
    loggedInAt: new Date().toISOString()
  });

  console.log('✅ 登录成功！');
  console.log(`   用户: ${data.user_id}`);
  console.log(`   套餐: ${data.plan}`);
  console.log(`   服务器: ${data.server_url || 'http://127.0.0.1:5577'}`);
  console.log('\n运行 `square-agent start` 开始。');
}

async function cmdStart() {
  const config = getConfig();
  if (!config?.apiKey) {
    console.error('❌ 尚未登录。请先运行: square-agent login --key sk-xxxxx');
    process.exit(1);
  }

  const isDaemon = cmdArgs.includes('--daemon');
  if (isDaemon) {
    const child = spawn(process.execPath, [process.argv[1], 'start'], {
      detached: true,
      stdio: 'ignore'
    });
    child.unref();
    writeFileSync(PID_FILE, child.pid.toString());
    console.log(`✅ 代理已在后台启动 (PID ${child.pid})`);
    console.log('   使用 `square-agent stop` 停止');
    console.log('   使用 `square-agent status` 查看状态');
    return;
  }

  console.log('🤖 SquareAgent 启动中...');
  console.log(`   用户: ${config.userId}`);
  console.log(`   服务器: ${config.serverUrl}`);
  console.log('   按 Ctrl+C 停止');
  console.log('─'.repeat(50));

  writeFileSync(PID_FILE, process.pid.toString());

  const deps = checkDependencies();
  console.log(`   Chrome: ${deps.chrome ? '✅' : '❌'}`);
  console.log(`   Peekaboo: ${deps.peekaboo ? '✅' : '❌'}`);
  console.log('');

  try {
    execSync(`node ${AGENT_DIR}/agent.mjs`, { stdio: 'inherit', timeout: 3600000 });
  } catch (e) {
    if (e.killed) console.log('代理已停止');
    else console.error('代理错误:', e.message);
  }
}

async function cmdStatus() {
  const config = getConfig();

  console.log('📊 SquareAgent 状态');
  console.log('─'.repeat(30));

  if (!config) {
    console.log('  ⚪ 未配置。请先运行: square-agent login --key sk-xxxxx');
  } else {
    console.log(`  用户:    ${config.userId || '-'}`);
    console.log(`  套餐:    ${config.plan || '-'}`);
    console.log(`  服务器:  ${config.serverUrl || '-'}`);
    console.log(`  登录时间: ${config.loggedInAt || '-'}`);
  }

  const pid = getPid();
  if (pid && isRunning(pid)) {
    console.log(`  代理:   🟢 运行中 (PID ${pid})`);
  } else {
    console.log('  代理:   ⚪ 已停止');
  }

  const deps = checkDependencies();
  console.log(`  Chrome:  ${deps.chrome ? '✅' : '❌'}`);
  console.log(`  Peekaboo: ${deps.peekaboo ? '✅' : '❌'}`);

  try {
    const today = new Date().toISOString().slice(0, 10);
    const logFile = join(LOG_DIR, `${today}.jsonl`);
    if (existsSync(logFile)) {
      const lines = readFileSync(logFile, 'utf8').trim().split('\n');
      console.log(`\n  今日日志 (${lines.length} 条，最近 5 条):`);
      lines.slice(-5).forEach(l => {
        try {
          const e = JSON.parse(l);
          const icon = e.success ? '✅' : '❌';
          console.log(`    ${icon} #${e.task_id} ${e.type || ''} ${e.duration_ms || 0}ms`);
        } catch {
          console.log(`    ${l}`);
        }
      });
    }
  } catch {}

  try {
    const statsFile = join(LOG_DIR, 'daily-stats.json');
    if (existsSync(statsFile)) {
      const stats = JSON.parse(readFileSync(statsFile, 'utf8'));
      console.log(`\n  每日统计: ${stats.posts} 篇帖子, ${stats.comments} 条评论, ${stats.follows} 次关注`);
    }
  } catch {}
}

async function cmdStop() {
  const pid = getPid();
  if (pid && isRunning(pid)) {
    try {
      process.kill(pid, 'SIGTERM');
      console.log(`✅ 代理已停止 (原 PID ${pid})`);
    } catch {
      console.log('⚠️ 无法停止代理');
    }
    try { require('fs').unlinkSync(PID_FILE); } catch {}
  } else {
    try {
      const pids = execSync('pgrep -f "square-agent-publisher/agent.mjs"', { encoding: 'utf8' }).trim().split('\n');
      pids.forEach(p => { try { process.kill(parseInt(p), 'SIGTERM'); } catch {} });
      console.log(`✅ 代理已停止 (PID: ${pids.join(', ')})`);
    } catch {
      console.log('⚠️ 代理未在运行');
    }
  }
}

async function cmdHistory() {
  const limit = parseInt(cmdArgs[0]) || 20;

  if (!existsSync(LOG_DIR)) {
    console.log('未找到日志。');
    return;
  }

  const files = readdirSync(LOG_DIR)
    .filter(f => f.endsWith('.jsonl'))
    .sort()
    .reverse();

  const entries = [];
  for (const f of files) {
    if (entries.length >= limit) break;
    try {
      const lines = readFileSync(join(LOG_DIR, f), 'utf8').trim().split('\n');
      for (let i = lines.length - 1; i >= 0 && entries.length < limit; i--) {
        try { entries.push(JSON.parse(lines[i])); } catch {}
      }
    } catch {}
  }

  if (entries.length === 0) {
    console.log('暂无历史记录。');
    return;
  }

  console.log(`📋 最近 ${entries.length} 条执行记录:`);
  console.log('─'.repeat(70));
  console.log('  时间                 任务   类型      状态  耗时');
  console.log('─'.repeat(70));
  entries.forEach(e => {
    const icon = e.success ? '✅' : '❌';
    const time = e.ts ? new Date(e.ts).toLocaleString('zh-CN', { hour12: false }) : '-';
    const taskId = String(e.task_id || '-').padEnd(5);
    const type = (e.type || '-').padEnd(9);
    const dur = `${e.duration_ms || 0}ms`.padEnd(8);
    console.log(`  ${time}  #${taskId} ${type} ${icon}   ${dur}`);
  });
}

async function cmdStates() {
  if (!existsSync(LOG_DIR)) {
    console.log('未找到日志。');
    return;
  }

  const files = readdirSync(LOG_DIR).filter(f => f.endsWith('.jsonl')).sort();

  let total = 0, success = 0, failed = 0;
  let totalDuration = 0;
  const byType = {};
  const byDate = {};

  for (const f of files) {
    try {
      const lines = readFileSync(join(LOG_DIR, f), 'utf8').trim().split('\n');
      for (const line of lines) {
        try {
          const e = JSON.parse(line);
          total++;
          if (e.success) success++; else failed++;
          totalDuration += e.duration_ms || 0;
          const type = e.type || '未知';
          byType[type] = (byType[type] || 0) + 1;
          const date = f.replace('.jsonl', '');
          byDate[date] = (byDate[date] || 0) + 1;
        } catch {}
      }
    } catch {}
  }

  console.log('📈 任务执行统计');
  console.log('─'.repeat(40));
  console.log(`  总计:     ${total}`);
  console.log(`  成功:     ${success} (${total ? ((success / total) * 100).toFixed(1) : 0}%)`);
  console.log(`  失败:     ${failed}`);
  console.log(`  平均耗时: ${total ? Math.round(totalDuration / total) : 0}ms`);
  console.log(`  总耗时:   ${Math.round(totalDuration / 1000)}s`);

  if (Object.keys(byType).length > 0) {
    console.log('\n  按类型:');
    Object.entries(byType).sort((a, b) => b[1] - a[1]).forEach(([type, count]) => {
      console.log(`    ${type.padEnd(12)} ${count}`);
    });
  }

  const recentDates = Object.entries(byDate).sort((a, b) => b[0].localeCompare(a[0])).slice(0, 7);
  if (recentDates.length > 0) {
    console.log('\n  最近 7 天:');
    recentDates.forEach(([date, count]) => {
      const bar = '█'.repeat(Math.min(count, 30));
      console.log(`    ${date}  ${bar} ${count}`);
    });
  }
}

async function cmdSetting() {
  const config = getConfig();

  if (!config) {
    console.log('⚠️ 未找到配置。请先运行: square-agent login --key sk-xxxxx');
    return;
  }

  const key = cmdArgs[0];
  const value = cmdArgs[1];

  if (!key) {
    console.log('⚙️  当前配置');
    console.log('─'.repeat(30));
    Object.entries(config).forEach(([k, v]) => {
      if (k === 'apiKey') {
        const masked = v.slice(0, 6) + '...' + v.slice(-4);
        console.log(`  ${k}: ${masked}`);
      } else {
        console.log(`  ${k}: ${v}`);
      }
    });
    return;
  }

  if (!value) {
    if (config[key] !== undefined) {
      console.log(`  ${key}: ${key === 'apiKey' ? config[key].slice(0, 6) + '...' + config[key].slice(-4) : config[key]}`);
    } else {
      console.log(`  ⚠️ 未知配置项: ${key}`);
      console.log(`  可用项: ${Object.keys(config).join(', ')}`);
    }
    return;
  }

  let parsed = value;
  try { parsed = JSON.parse(value); } catch {}
  config[key] = parsed;
  saveConfig(config);
  console.log(`✅ ${key} = ${value}`);
}

async function cmdAnalytics() {
  const subcmd = cmdArgs[0] || 'all';
  if (subcmd === 'stats' || subcmd === 'all') {
    console.log('\n=== 每日统计 ===');
    try { execSync(`node ${AGENT_DIR}/analytics/daily-stats.mjs`, { stdio: 'inherit' }); } catch {}
  }
  if (subcmd === 'hot-topics' || subcmd === 'all') {
    console.log('\n=== 热点报告 ===');
    try { execSync(`node ${AGENT_DIR}/analytics/hot-topics.mjs`, { stdio: 'inherit' }); } catch {}
  }
  if (subcmd === 'engagement' || subcmd === 'all') {
    console.log('\n=== 互动分析 ===');
    try { execSync(`node ${AGENT_DIR}/analytics/engagement-analysis.mjs`, { stdio: 'inherit' }); } catch {}
  }
  if (subcmd === 'scrape' || subcmd === 'all') {
    console.log('\n=== 创作者中心数据抓取 ===');
    try { execSync(`node ${AGENT_DIR}/analytics/scrape-creator-center.mjs`, { stdio: 'inherit' }); } catch {}
  }
  if (subcmd === 'weekly' || subcmd === 'all') {
    console.log('\n=== 周度报告 ===');
    try { execSync(`node ${AGENT_DIR}/analytics/weekly-report.mjs`, { stdio: 'inherit' }); } catch {}
  }
}

function cmdHelp() {
  console.log(`
SquareAgent - 币安广场自动发布代理

用法: square-agent <命令> [选项]

命令:
  login --key <密钥>   使用 API Key 登录 (sk-xxxxx)
  start [--daemon]     启动代理（前台或后台）
  stop                 停止后台代理
  status               查看代理状态、依赖、最近日志
  setting [key] [val]  查看/修改配置
  history [n]          查看最近 n 条执行记录（默认20）
  states               查看任务执行统计
  analytics <子命令>   运行数据分析
                stats       - 每日操作统计
                hot-topics  - 早间热点报告
                engagement  - 互动分析报告
                scrape      - 抓取币安创作者中心数据
                weekly      - 周度互动报告
                all         - 运行所有分析
  help                 显示此帮助
`);
}

// ========== 入口 ==========

switch (command) {
  case 'login': await cmdLogin(); break;
  case 'start': await cmdStart(); break;
  case 'stop': await cmdStop(); break;
  case 'status': await cmdStatus(); break;
  case 'setting': await cmdSetting(); break;
  case 'history': await cmdHistory(); break;
  case 'states': await cmdStates(); break;
  case 'analytics': await cmdAnalytics(); break;
  case 'help': cmdHelp(); break;
  default:
    console.log(`未知命令: ${command}`);
    cmdHelp();
}
