#!/bin/bash
# Binsquare Agent 启动脚本
# 用 exec 替换 bash 进程，确保只有一个进程

# 禁用 launchd 自动启动
export LAUNCHD_DISABLE=1

export SERVER_URL=http://localhost:3100
export AGENT_TOKEN=bsq_mq4vcmum_hk9zvg

# 用 exec 替换当前进程
exec /Users/mac/.nvm/versions/node/v24.13.0/bin/node /Users/mac/.square-agent-publisher/agent.mjs
