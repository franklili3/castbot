/**
 * 操作码映射表
 * 
 * 云端下发的任务只包含 { k, p, d } 格式的操作序列
 * Agent通过此映射表将操作码还原为实际执行逻辑
 */

const OPCODES = {
  // ===== 基础操作 =====
  0x01: 'navigate',
  0x02: 'click_coords',
  0x03: 'click_global',
  0x04: 'paste_text',
  0x05: 'type_text',
  0x06: 'press_key',
  0x07: 'run_js',
  0x08: 'sleep',

  // ===== 复合操作 =====
  0x10: 'expand_editor',
  0x11: 'focus_editor',
  0x12: 'input_content',
  0x13: 'scroll_top',
  0x14: 'add_topics',

  // ===== 投票操作 =====
  0x20: 'open_more_menu',
  0x21: 'create_poll',
  0x22: 'fill_poll_option',
  0x23: 'verify_poll_inputs',

  // ===== 发布操作 =====
  0x30: 'find_publish_btn',
  0x31: 'click_publish',

  // ===== 检查操作 =====
  0x40: 'check_focus',
  0x41: 'verify_content',
  0x42: 'check_pm_exists',

  // ===== 评论操作 =====
  0x50: 'find_comment_box',
  0x51: 'submit_comment',
};

// JS代码模板（按code_id查表）
const JS_TEMPLATES = {
  'focus_pm':    '(function(){var pm=document.querySelector(".ProseMirror");if(!pm)return"no_pm";pm.style.minHeight="300px";pm.focus();return"ok";})()',
  'scroll_top':  'window.scrollTo(0,0)',
  'check_pm':    '(function(){var pm=document.querySelector(".ProseMirror");return pm?"len="+pm.textContent.length:"no_pm";})()',
  'check_focus': '(function(){return document.activeElement.tagName+" "+(document.activeElement.placeholder||"")})()',
  'click_vote':  '(function(){var a=document.querySelectorAll("*");for(var i=0;i<a.length;i++){if((a[i].textContent||"").trim()==="PLACEHOLDER"){var r=a[i].getBoundingClientRect();if(r.y>YMIN&&r.y<YMAX){a[i].click();return"clicked";}}}return"not_found";})()',
  'find_inputs': '(function(){var inputs=document.querySelectorAll("input");var r=[];for(var i=0;i<inputs.length;i++){var rect=inputs[i].getBoundingClientRect();if(rect.y>YMIN&&rect.y<YMAX&&rect.width>MINW){r.push(inputs[i].placeholder+":y="+Math.round(rect.y));}}return r.join("|")||"NO_INPUTS";})()',
  'find_btn':    '(function(){var btns=document.querySelectorAll("button");for(var i=0;i<btns.length;i++){var t=btns[i].textContent.trim(),rect=btns[i].getBoundingClientRect();if(t==="PLACEHOLDER"&&rect.x>XMIN&&rect.x<XMAX&&rect.width>WMIN&&rect.width<WMAX&&getComputedStyle(btns[i]).opacity!=="0.3")return"y="+Math.round(rect.y);}return"not_found";})()',
  'find_comment':'(function(){var els=document.querySelectorAll("textarea,[contenteditable=true]");for(var i=0;i<els.length;i++){var rect=els[i].getBoundingClientRect();if(rect.width>200&&rect.y>200){els[i].focus();return"found y="+Math.round(rect.y);}}return"not_found";})()',
  'submit':      '(function(){var btns=document.querySelectorAll("button");for(var i=0;i<btns.length;i++){var t=btns[i].textContent.trim();if(t==="发送"||t==="提交"||t==="回复"){btns[i].click();return"submitted";}}return"no_submit_btn";})()',
};

// Chrome窗口偏移
const CHROME_OFFSET = {
  screen_y: 30,
  ui_height: 121
};

export { OPCODES, JS_TEMPLATES, CHROME_OFFSET };

/**
 * 将云端下发的ops数组还原为可执行步骤
 * @param {Array} ops - [{k, p?, d?}, ...]
 * @returns {Array} [{op, params, delay}, ...]
 */
export function decodeOps(ops) {
  return ops.map(op => ({
    op: OPCODES[op.k],
    params: op.p || [],
    delay: op.d || 0
  })).filter(step => step.op);
}
