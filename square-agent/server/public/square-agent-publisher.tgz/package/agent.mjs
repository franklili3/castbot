#!/usr/bin/env node
/**
 * Binsquare Agent v0.2.0
 *
 * 客户端本地运行 - 轮询服务器获取待发布内容,通过本地 Chrome 发布到币安广场
 *
 * v0.2.0 改进:
 * - 使用 execCommand('insertText') + dispatchEvent(input) 输入中文(不会被截断)
 * - 操作码引擎:云端下发 ops 序列,Agent 本地解码执行
 * - 拟人化延迟(humanize.mjs)
 * - 评论功能:先触发 ProseMirror,再用 execCommand 输入
 * - 短贴模式:insertText → 话题标签 → 发布
 * - 投票模式:输入问题 → 更多按钮 → 创建投票 → 填选项 → 发布
 */

import { execSync } from 'child_process';
import { writeFileSync, readFileSync, existsSync, mkdirSync, appendFileSync } from 'fs';
import { hostname } from 'os';
import { homedir } from 'os';
import { join } from 'path';

// ============ 配置 ============
const SERVER_URL = process.env.SERVER_URL || 'http://localhost:3100';
const API_KEY = process.env.API_KEY || 'binsquare-dev-key-2026';
const POLL_INTERVAL = parseInt(process.env.POLL_INTERVAL || '30000');
const publishedSet = new Set();
const AGENT_TOKEN = process.env.AGENT_TOKEN;

if (!AGENT_TOKEN) {
  console.error('❌ 请设置 AGENT_TOKEN');
  console.error('   运行: AGENT_TOKEN=bsq_xxxxx node agent.mjs');
  process.exit(1);
}

// ============ 日志 ============
const LOG_DIR = join(homedir(), '.square-agent-publisher', 'logs');

function writeLog(task, result) {
  if (!existsSync(LOG_DIR)) mkdirSync(LOG_DIR, { recursive: true });
  const logFile = join(LOG_DIR, `${new Date().toISOString().split('T')[0]}.jsonl`);
  const entry = {
    ts: new Date().toISOString(),
    task_id: task.id,
    type: task.type,
    success: result.success,
    error: result.error,
    duration_ms: result.duration_ms,
    steps: result.steps?.length || 0
  };
  appendFileSync(logFile, JSON.stringify(entry) + '\n');
}

function ts() {
  return new Date().toLocaleString('zh-CN', { hour12: false });
}

// ============ API ============
async function api(path, options = {}) {
  const res = await fetch(`${SERVER_URL}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'X-API-Key': API_KEY,
      ...(options.headers || {}),
    },
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || `API ${res.status}`);
  return data;
}

// ============ 注册 ============
let agentId = '';
let userId = '';

async function register() {
  const data = await api('/api/agent/register', {
    method: 'POST',
    body: JSON.stringify({ token: AGENT_TOKEN, hostname: hostname(), platform: process.platform }),
  });
  agentId = data.agentId;
  userId = data.user.id;
  console.log(`✅ 已连接 | 币安 UID: ${data.user.binance_uid} | 风格: ${data.user.style}`);
}

// ============ 心跳 ============
async function heartbeat() {
  if (!agentId) return;
  try { await api('/api/agent/heartbeat', { method: 'POST', body: JSON.stringify({ agentId }) }); } catch {}
}

// ============ 获取待发布 ============
async function fetchPending() {
  return (await api(`/api/content/pending?userId=${userId}`)).posts;
}

// ============ 回传状态 ============
async function reportStatus(postId, status, binancePostId, error, steps) {
  try {
    await api(`/api/content/${postId}/status`, {
      method: 'POST',
      body: JSON.stringify({ status, binancePostId, error }),
    });
  } catch (e) {
    console.error(`  ⚠️ reportStatus failed for #${postId}: ${e.message}`);
  }
  try {
    await api('/api/agent/log', {
      method: 'POST',
      body: JSON.stringify({ agentId, postId, log: { status, error: error || null, steps } }),
    });
  } catch {}
}

// ============ 底层工具 ============
const sleep = ms => new Promise(r => setTimeout(r, ms));
const sleepSync = ms => execSync(`sleep ${ms / 1000}`, { timeout: ms + 5000 });

function run(cmd) {
  try { return { ok: true, data: execSync(cmd, { timeout: 15000 }).toString().trim() }; }
  catch (e) { return { ok: false, error: (e.stderr || e).toString().substring(0, 300) }; }
}

/**
 * 在 Chrome 中执行 JS
 * 使用临时文件避免 shell 转义问题(中文内容安全)
 */
function js(code) {
  const f = `/tmp/binsq-${Date.now()}.js`;
  writeFileSync(f, code);
  const r = run(`osascript -e 'tell application "Google Chrome" to tell active tab of window 1 to return execute javascript (do shell script "cat ${f}")'`);
  // 清理临时文件
  try { execSync(`rm -f ${f}`, { timeout: 2000 }); } catch {}
  return r;
}

let HAS_PEEKABOO = false;
try { HAS_PEEKABOO = run('which peekaboo').ok; } catch {}

/**
 * 执行 peekaboo 命令,不可用时用 AppleScript/JS 替代
 */
function pk(action, args = '') {
  if (HAS_PEEKABOO) {
    return run(`peekaboo ${action} ${args}`.trim());
  }
  // === peekaboo 不可用时的替代方案 ===
  if (action === 'type') {
    // 用 AppleScript 模拟键盘输入
    const text = args.replace(/^"(.*)".*$/, '$1');
    const escaped = text.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
    return run(`osascript -e 'tell application "System Events" to keystroke "${escaped}"'`);
  }
  if (action === 'press') {
    const keyMap = { 'enter': 'key code 36', 'return': 'key code 36', 'delete': 'key code 51', 'down': 'key code 125', 'up': 'key code 126', 'tab': 'key code 48', 'escape': 'key code 53', 'space': 'key code 49' };
    const keyName = args.replace(/\s*--app.*$/, '').trim();
    const keyCode = keyMap[keyName];
    if (keyCode) return run(`osascript -e 'tell application "System Events" to ${keyCode}'`);
    return { ok: false, error: `unsupported key: ${keyName}` };
  }
  if (action === 'click') {
    // 用 AppleScript 点击
    const coordsMatch = args.match(/coords\s+(\d+),(\d+)/);
    const globalMatch = args.includes('global-coords');
    if (coordsMatch) {
      const x = coordsMatch[1], y = coordsMatch[2];
      if (globalMatch) {
        return run(`osascript -e 'tell application "System Events" to click at {${x}, ${y}}'`);
      } else {
        // 需要 Chrome 窗口偏移
        return run(`osascript -e 'tell application "System Events" to click at {${x}, ${y}}'`);
      }
    }
    return { ok: false, error: 'no coords' };
  }
  return { ok: false, error: `peekaboo not available: ${action}` };
}

/**
 * 用 JS 点击元素(不依赖 peekaboo)
 */
function jsClick(selectorOrCoords, y) {
  if (typeof selectorOrCoords === 'string') {
    return js(`(function(){var el=document.querySelector('${selectorOrCoords}'); if(!el) return 'not_found'; el.click(); return 'clicked';})()`);
  }
  // 坐标点击
  return js(`(function(){var el=document.elementFromPoint(${selectorOrCoords},${y}); if(!el) return 'nothing'; el.click(); return 'clicked '+el.tagName;})()`);
}

// ============ CDP + CGEvent 支持 ============
const CDP_PORT = parseInt(process.env.CDP_PORT || '9222');

/**
 * 检查 CDP 是否可用(端口是否在监听)
 */
function isCdpAvailable() {
  return run(`lsof -i :${CDP_PORT} -sTCP:LISTEN -P -n`).ok;
}

/**
 * 使用 Python CGEvent 执行原生鼠标点击(React 能识别 isTrusted 事件)
 * CDP Input.dispatchMouseEvent 无法触发 React 的下拉菜单
 */
function cgClick(globalX, globalY) {
  const script = `
import Quartz, subprocess, time
subprocess.run(['osascript', '-e', 'tell application "Google Chrome" to activate'])
time.sleep(0.3)
move = Quartz.CGEventCreateMouseEvent(None, Quartz.kCGEventMouseMoved, (${globalX}, ${globalY}), Quartz.kCGMouseButtonLeft)
Quartz.CGEventPost(Quartz.kCGHIDEventTap, move)
time.sleep(0.15)
down = Quartz.CGEventCreateMouseEvent(None, Quartz.kCGEventLeftMouseDown, (${globalX}, ${globalY}), Quartz.kCGMouseButtonLeft)
Quartz.CGEventPost(Quartz.kCGHIDEventTap, down)
time.sleep(0.08)
up = Quartz.CGEventCreateMouseEvent(None, Quartz.kCGEventLeftMouseUp, (${globalX}, ${globalY}), Quartz.kCGMouseButtonLeft)
Quartz.CGEventPost(Quartz.kCGHIDEventTap, up)
print("ok")
`;
  return run(`python3 -c '${script.replace(/'/g, "'\"'\"'")}'`);
}

/**
 * 通过 CDP WebSocket 发送 Input.insertText(用于填写投票选项输入框)
 * 比键盘模拟更可靠,支持中文
 */
async function cdpInsertText(text) {
  const listRes = run(`curl -s http://127.0.0.1:${CDP_PORT}/json/list`);
  if (!listRes.ok) return { ok: false, error: 'cdp_curl_failed' };
  let pages;
  try { pages = JSON.parse(listRes.data); } catch { return { ok: false, error: 'cdp_parse_error' }; }
  const page = pages.find(p => p.url && p.url.includes('binance.com'));
  if (!page) return { ok: false, error: 'no_binance_page' };
  const wsUrl = page.webSocketDebuggerUrl;
  if (!wsUrl) return { ok: false, error: 'no_ws_url' };

  return new Promise((resolve) => {
    let settled = false;
    try {
      const ws = new WebSocket(wsUrl);
      const timeout = setTimeout(() => {
        if (!settled) { settled = true; ws.close(); resolve({ ok: false, error: 'cdp_timeout' }); }
      }, 5000);
      ws.addEventListener('open', () => {
        ws.send(JSON.stringify({ id: 1, method: 'Input.insertText', params: { text } }));
      });
      ws.addEventListener('message', (ev) => {
        const msg = JSON.parse(ev.data);
        if (msg.id === 1) {
          clearTimeout(timeout);
          if (!settled) { settled = true; ws.close(); resolve({ ok: !msg.error, data: JSON.stringify(msg.result || msg.error) }); }
        }
      });
      ws.addEventListener('error', () => {
        clearTimeout(timeout);
        if (!settled) { settled = true; resolve({ ok: false, error: 'ws_error' }); }
      });
    } catch (err) {
      if (!settled) { settled = true; resolve({ ok: false, error: err.message }); }
    }
  });
}

/**
 * 清空 ProseMirror 编辑器内容
 */
function clearEditor() {
  js("(function(){var pm=document.querySelector('.ProseMirror'); if(pm){pm.innerHTML='<p><br></p>'; pm.dispatchEvent(new Event('input',{bubbles:true}));} return 'cleared';})()");
}

// ============ 拟人化延迟(内联简化版) ============
function humanDelay(baseMs) {
  const jitter = baseMs * (Math.random() * 0.6 - 0.3);
  const hesitation = Math.random() < 0.1 ? (1000 + Math.random() * 2000) : 0;
  return Math.max(100, Math.round(baseMs + jitter + hesitation));
}

const humanSleep = (baseMs) => sleep(humanDelay(baseMs));

// ============ Chrome 偏移(动态获取) ============
function getChromeOffset() {
  // 先激活 Chrome 确保窗口可见
  run(`osascript -e 'tell application "Google Chrome" to activate'`);
  sleep(500);

  const r = run(`osascript -e 'tell application "Google Chrome" to get bounds of window 1'`);
  if (r.ok) {
    // bounds format: left, top, right, bottom
    const parts = r.data.split(', ').map(Number);
    if (parts.length === 4) {
      const windowTop = parts[1];
      const windowH = parts[3] - parts[1];
      // 窗口最小化或不可见时 screen_y 会非常大/小
      if (windowTop > 2000 || windowTop < -500 || windowH < 100) {
        console.log(`  ⚠️ Chrome 窗口异常: bounds=${r.data}, 跳过投票`);
        return { screen_y: 30, ui_height: 121, valid: false };
      }
      // 通过 JS 获取 innerHeight vs outerHeight 来算偏移
      const jsOffset = js('(function(){return window.outerHeight - window.innerHeight;})()');
      let uiHeight = 121; // default
      if (jsOffset.ok && jsOffset.data) {
        uiHeight = parseInt(jsOffset.data) || 121;
      }
      // uiHeight 异常检查
      if (uiHeight < 0 || uiHeight > 500) {
        console.log(`  ⚠️ uiHeight 异常: ${uiHeight}, 使用默认值 121`);
        uiHeight = 121;
      }
      return { screen_x: parts[0], screen_y: windowTop, ui_height: uiHeight, valid: true };
    }
  }
  return { screen_x: 0, screen_y: 30, ui_height: 121, valid: false };
}

function viewportToGlobal(viewportY) {
  const offset = getChromeOffset();
  return offset.screen_y + offset.ui_height + viewportY;
}

// ============ 核心发布逻辑 ============

/**
 * 使用 execCommand('insertText') 向 ProseMirror 编辑器插入内容
 * 关键改进:中文不会被截断(peekaboo type 有这个问题)
 */
function insertTextViaExec(text) {
  // ✅ innerHTML + <p> 标签设置内容 + peekaboo type 触发 React 更新
  const lines = text.split('\n');
  const htmlParts = lines.map(line => {
    if (line.trim() === '') return '<p><br></p>';
    const escaped = line.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    return '<p>' + escaped + '</p>';
  });
  const html = htmlParts.join('');
  const escapedHtml = html.replace(/\\/g,'\\\\').replace(/`/g,'\\`').replace(/\$/g,'\\$');
  const setResult = js(`
(function() {
  var pm = document.querySelector('.ProseMirror');
  if (!pm) return 'no_pm';
  pm.parentElement.setAttribute('aria-expanded','true');
  pm.style.minHeight = '300px';
  pm.innerHTML = \`${escapedHtml}\`;
  pm.dispatchEvent(new Event('input', { bubbles: true }));
  return 'ok_len=' + pm.textContent.length;
})()
  `.trim());

  // innerHTML 不触发 React 状态更新,用 peekaboo type 输入空格再删除来激活发文按钮
  if (HAS_PEEKABOO && setResult.ok) {
    // 先把光标移到末尾,确保 peekaboo type 在末尾触发
    js("(function(){var pm=document.querySelector('.ProseMirror'); if(!pm) return; pm.focus(); var r=document.createRange(); r.selectNodeContents(pm); r.collapse(false); var s=window.getSelection(); s.removeAllRanges(); s.addRange(r); return 'ok';})()");
    pk('type', '" " --app "Google Chrome"');
    pk('press', 'delete --app "Google Chrome"');
  }

  return setResult;
}

/**
 * 使用 innerHTML 设置 ProseMirror 内容(备用,主流程用 insertText)
 */
function setContentViaInnerHTML(htmlContent) {
  const escaped = htmlContent
    .replace(/\\/g, '\\\\')
    .replace(/`/g, '\\`')
    .replace(/\$/g, '\\$');
  return js(`
(function() {
  var pm = document.querySelector('.ProseMirror');
  if (!pm) return 'no_pm';
  pm.innerHTML = \`${escaped}\`;
  pm.dispatchEvent(new Event('input', { bubbles: true }));
  return 'ok_len=' + pm.textContent.length;
})()
  `.trim());
}

/**
 * 导航到币安广场
 */
async function navigateToSquare() {
  // 先检查当前 URL,如果已经在广场首页则不需要导航
  const urlResult = js('(function(){return window.location.href;})()');
  const currentUrl = urlResult.data || '';
  if (currentUrl.match(/binance\.com\/zh-CN\/square\/?$/) || currentUrl.match(/binance\.com\/zh-CN\/square\?/)) {
    // 已经在广场首页,刷新确保干净状态
    console.log('  📍 已在广场首页,刷新...');
    js('window.location.reload()');
    await sleep(4000);
    return;
  }
  console.log('  📍 导航到广场首页...');
  run('osascript -e \'tell application "Google Chrome" to tell window 1 to set URL of active tab to "https://www.binance.com/zh-CN/square"\'');
  await sleep(5000);
  // 验证是否真的到了广场首页
  const checkUrl = js('(function(){return window.location.href;})()');
  if ((checkUrl.data || '').includes('creator-center')) {
    console.log('  ⚠️ 仍在创作者中心,强制刷新...');
    js('window.location.href = "https://www.binance.com/zh-CN/square"');
    await sleep(5000);
  }
}

/**
 * 点击编辑器展开
 */
async function expandEditor() {
  // 用 JS 直接展开编辑器
  js("(function(){var pm=document.querySelector('.ProseMirror'); if(!pm) return 'no_pm'; pm.parentElement.setAttribute('aria-expanded','true'); pm.style.minHeight='300px'; pm.focus(); return 'expanded';})()");
  await sleep(500);
}

/**
 * 聚焦 ProseMirror 编辑器
 */
function maximizeWindow() {
  try {
    if (HAS_PEEKABOO) {
      // 用 AppleScript 最大化 Chrome(比 peekaboo 更可靠)
    }
    // 先把 Chrome 带到前台并全屏
    run('osascript -e \'tell application "Google Chrome" to activate\'');
    sleepSync(500);
    // macOS: 用 zoom (Cmd+Ctrl+F) 或直接设置 window bounds
    run('osascript -e \'tell application "Google Chrome" to set bounds of front window to {0, 0, 1920, 1080}\'');
    sleepSync(500);
    console.log('  📺 Chrome window maximized');
  } catch (e) {
    console.log('  ⚠️ maximize failed:', e.message);
  }
}

function focusEditor() {
  return js(`
(function() {
  var pm = document.querySelector('.ProseMirror');
  if (!pm) return 'no_pm';
  pm.style.minHeight = '300px';
  pm.focus();
  return 'ok';
})()
  `.trim());
}

/**
 * 查找并点击发文按钮
 */
function findPublishButton() {
  return js(`
(function() {
  var btns = document.querySelectorAll('button');
  var candidates = [];
  for (var i = 0; i < btns.length; i++) {
    var t = btns[i].textContent.trim();
    var rect = btns[i].getBoundingClientRect();
    var s = getComputedStyle(btns[i]);
    // 只选编辑器内小按钮(w<100),排除侧边栏大按钮(w≈240)
    if ((t === '发文' || t === '发布' || t === 'Post') && rect.width > 30 && rect.width < 100 && s.cursor === 'pointer' && parseFloat(s.opacity) > 0.5) {
      candidates.push({text: t, x: Math.round(rect.x), y: Math.round(rect.y), w: Math.round(rect.width)});
    }
  }
  if (candidates.length > 0) return 'y=' + candidates[0].y + '&w=' + candidates[0].w + '&found=' + candidates.length;
  return 'not_found';
})()
  `.trim());
}

/**
 * 点击发布按钮(通过坐标)
 */
function clickPublishBtn(btnViewportY) {
  // 用 JS 直接点击编辑器内发文按钮(w<100 排除侧边栏大按钮 w≈240)
  return js(`(function(){var btns=document.querySelectorAll('button'); for(var i=0;i<btns.length;i++){var t=btns[i].textContent.trim(); var rect=btns[i].getBoundingClientRect(); var s=getComputedStyle(btns[i]); if((t==='发文'||t==='发布'||t==='Post')&&Math.abs(Math.round(rect.y)-${btnViewportY})<20&&rect.width>30&&rect.width<100&&s.cursor==='pointer'&&parseFloat(s.opacity)>0.5){btns[i].click(); return 'clicked y='+Math.round(rect.y)+' w='+Math.round(rect.width);}} return 'not_found';})()`);
}

/**
 * 添加话题标签
 */
async function addTopics(topics) {
  if (!topics || topics.length === 0) return [];
  const results = [];
  // 先记录初始标签数量
  const initialCount = parseInt((js("(function(){return ''+document.querySelectorAll('[data-type=hashtag],[class*=richtext-hashtag]').length;})()").data) || '0');
  console.log(`  🏷️ 初始标签数=${initialCount}, 待添加=${topics.length}`);

  for (let ti = 0; ti < topics.length; ti++) {
    const topic = topics[ti];
    // 1. 光标移到编辑器末尾(innerHTML 后必须手动定位)
    js("(function(){var pm=document.querySelector('.ProseMirror'); if(!pm) return; pm.focus(); var r=document.createRange(); r.selectNodeContents(pm); r.collapse(false); var s=window.getSelection(); s.removeAllRanges(); s.addRange(r); return 'cursor_end';})()");
    await humanSleep(500);

    // 2. execCommand 一次性插入 #话题(不用 peekaboo type,避免逐字符触发下拉框)
    const tag = ' #' + topic;
    const esc = tag.replace(/\\/g,'\\\\').replace(/`/g,'\\`').replace(/\$/g,'\\$');
    const insertR = js(`(function(){try{document.execCommand('insertText',false,\`${esc}\`); return 'OK';}catch(e){return 'ERR:'+e.message;}})()`);
    console.log(`  ⌨️ #${topic} insert → ${insertR.data}`);
    await humanSleep(3000);

    // 3. JS 点击下拉框第一项
    const clickR = js("(function(){var sug=document.querySelector('.editor-suggestion'); if(!sug) return 'NO_SUG'; var items=sug.querySelectorAll(':scope > div'); if(!items.length) return 'NO_ITEMS'; items[0].click(); return 'CLICKED:'+items.length;})()");
    console.log(`  🖱️ #${topic} click → ${clickR.data}`);
    await humanSleep(1500);

    // 4. 验证标签是否增加
    const cnt = parseInt((js("(function(){return ''+document.querySelectorAll('[data-type=hashtag],[class*=richtext-hashtag]').length;})()").data) || '0');
    const expected = initialCount + ti + 1;
    const ok = cnt >= expected;
    console.log(`  ${ok ? '✅' : '⚠️'} #${topic} ${ok ? '生效' : '未生效'} (total=${cnt}, expected>=${expected})`);
    results.push({ topic, ok });
  }
  return results;
}

// ============ 评论功能 ============

/**
 * 查找并聚焦评论输入框
 */
function findCommentBox() {
  return js(`
(function() {
  // 先查找 placeholder 提示的评论输入框
  var inputs = document.querySelectorAll('input[placeholder]');
  for (var i = 0; i < inputs.length; i++) {
    var ph = inputs[i].placeholder || '';
    if (ph.includes('回复') || ph.includes('评论') || ph.includes('发布您的回复')) {
      var rect = inputs[i].getBoundingClientRect();
      if (rect.width > 100 && rect.y > 200) {
        inputs[i].click();
        return 'clicked_placeholder y=' + Math.round(rect.y);
      }
    }
  }
  // 查找 ProseMirror 或 contenteditable
  var els = document.querySelectorAll('[contenteditable=true], textarea');
  for (var i = 0; i < els.length; i++) {
    var rect = els[i].getBoundingClientRect();
    if (rect.width > 200 && rect.y > 200) {
      els[i].focus();
      return 'found_editable y=' + Math.round(rect.y);
    }
  }
  return 'not_found';
})()
  `.trim());
}

/**
 * 提交评论
 */
function submitComment() {
  return js(`
(function() {
  var btns = document.querySelectorAll('button');
  for (var i = 0; i < btns.length; i++) {
    var t = btns[i].textContent.trim();
    if (t === '发送' || t === '提交' || t === '回复') {
      btns[i].click();
      return 'submitted';
    }
  }
  return 'no_submit_btn';
})()
  `.trim());
}

// ============ 操作码引擎 ============

/**
 * 将内容转换为 HTML 段落
 */
function contentToHtml(content) {
  return content.split('\n').map(line => {
    if (line.trim() === '') return '<br>';
    return `<p>${line}</p>`;
  }).join('');
}

/**
 * 执行单个操作码
 */
async function executeOp(op, params, taskData) {
  switch (op) {
    case 'navigate':
      run(`osascript -e 'tell application "Google Chrome" to tell window 1 to set URL of active tab to "${params[0]}"'`);
      return { ok: true, data: 'navigated' };

    case 'click_coords': {
      const j = jitterCoords(params[0], params[1], 3);
      return pk('click', `--coords ${j.x},${j.y} --app "Google Chrome"`);
    }

    case 'click_global': {
      const j = jitterCoords(params[0], params[1], 3);
      return pk('click', `--global-coords --coords ${j.x},${j.y} --app "Google Chrome"`);
    }

    case 'paste_text': {
      const text = (taskData.content || params[0] || '').replace(/\\/g, '\\\\').replace(/"/g, '\\"');
      return pk('paste', `--text "${text}" --app "Google Chrome"`);
    }

    case 'type_text':
      return pk('type', `"${params[0]}" --app "Google Chrome"`);

    case 'press_key':
      return pk('press', `${params[0]} --app "Google Chrome"`);

    case 'run_js':
      return js(params[0]);

    case 'sleep':
      await sleep(params[0] || 1000);
      return { ok: true, data: `slept ${params[0]}ms` };

    case 'expand_editor':
      await expandEditor();
      return { ok: true, data: 'clicked_editor' };

    case 'focus_editor':
      return focusEditor();

    case 'input_content':
      // 核心改进:使用 execCommand 输入中文
      return insertTextViaExec(taskData.content || '');

    case 'scroll_top':
      return js('window.scrollTo(0,0)');

    case 'add_topics':
      await addTopics(taskData.topics);
      return { ok: true, data: taskData.topics?.join(',') || 'none' };

    case 'find_publish_btn': {
      const r = findPublishButton();
      const yMatch = (r.data || '').match(/y=(\d+)/);
      if (yMatch) taskData._btnViewportY = parseInt(yMatch[1]);
      return r;
    }

    case 'click_publish': {
      const bvy = taskData._btnViewportY;
      if (!bvy) return { ok: false, data: 'no_btn_y' };
      return clickPublishBtn(bvy);
    }

    case 'check_focus':
      return js('(function(){return document.activeElement.tagName+" "+(document.activeElement.placeholder||"")})()');

    case 'verify_content':
      return js('(function(){var pm=document.querySelector(".ProseMirror");return pm?"len="+pm.textContent.length:"no_pm";})()');

    case 'check_pm_exists':
      return js('(function(){var pm=document.querySelector(".ProseMirror");return pm?"exists":"no_pm";})()');

    case 'find_comment_box':
      return findCommentBox();

    case 'submit_comment':
      return submitComment();

    // ===== 投票操作 =====
    case 'open_more_menu': {
      // 点击工具栏"更多"按钮(三个点图标)
      // 先找到编辑器工具栏位置
      const toolbarResult = js(`(function(){var tb=document.querySelector('.editor-toolbar-container'); if(!tb) return 'no_toolbar'; var r=tb.getBoundingClientRect(); return 'x='+Math.round(r.x+r.width-40)+',y='+Math.round(r.y+r.height/2);})()`);
      if (!toolbarResult.ok) return toolbarResult;
      const tm = (toolbarResult.data || '').match(/x=(\d+),y=(\d+)/);
      if (!tm) return { ok: false, error: 'toolbar not found' };
      const globalY = viewportToGlobal(parseInt(tm[2]));
      return pk('click', `--global-coords --coords ${tm[1]},${globalY} --app "Google Chrome"`);
    }

    case 'create_poll': {
      // 点击下拉菜单中的"创建投票"
      return js(`(function(){var all=document.querySelectorAll('*'); for(var i=0;i<all.length;i++){var t=(all[i].textContent||'').trim(); if(t==='创建投票'){var r=all[i].getBoundingClientRect(); if(r.width>0 && r.width<200){all[i].click(); return 'clicked_vote y='+Math.round(r.y);}}} return 'not_found';})()`);
    }

    case 'fill_poll_option': {
      // params: [optionIndex(0-based), optionText]
      const idx = params[0] || 0;
      const text = params[1] || '';
      // 找到所有选项 input
      const inputsResult = js(`(function(){var inputs=document.querySelectorAll('input[type=text]'); var opts=[]; for(var i=0;i<inputs.length;i++){var ph=inputs[i].getAttribute('placeholder')||''; var r=inputs[i].getBoundingClientRect(); if(ph.indexOf('选项')>=0||(r.y>350 && r.width>100)){opts.push({idx:opts.length, y:Math.round(r.y), x:Math.round(r.x), w:Math.round(r.width)});}} return JSON.stringify(opts);})()`);
      if (!inputsResult.ok) return inputsResult;
      let opts = [];
      try { opts = JSON.parse(inputsResult.data); } catch {}
      if (idx >= opts.length) return { ok: false, error: `option ${idx} not found, have ${opts.length}` };
      const opt = opts[idx];
      // 点击选项 input 左侧
      const clickX = Math.max(opt.x + 10, 490);
      const clickY = viewportToGlobal(opt.y + opt.w/4);
      pk('click', `--global-coords --coords ${clickX},${clickY} --app "Google Chrome"`);
      await sleep(500);
      // 输入选项文本
      pk('type', `"${text}" --app "Google Chrome"`);
      return { ok: true, data: `filled option ${idx}: ${text}` };
    }

    case 'verify_poll_inputs': {
      return js(`(function(){var inputs=document.querySelectorAll('input[type=text]'); var r=[]; for(var i=0;i<inputs.length;i++){var ph=inputs[i].getAttribute('placeholder')||''; if(ph.indexOf('选项')>=0||r.length<4){var rect=inputs[i].getBoundingClientRect(); if(rect.width>50) r.push({ph:ph,val:inputs[i].value,y:Math.round(rect.y)});}} return JSON.stringify(r);})()`);
    }

    default:
      return { ok: false, error: `unknown_op: ${op}` };
  }
}

function jitterCoords(x, y, maxOffset = 3) {
  return {
    x: Math.round(x + (Math.random() - 0.5) * maxOffset),
    y: Math.round(y + (Math.random() - 0.5) * maxOffset)
  };
}

/**
 * 执行云端下发的操作码序列
 * @param {Object} task - { id, type, ops: [{k,p,d},...], content, topics }
 * @returns {Object} { success, steps, duration_ms }
 */
async function executeOpsTask(task) {
  const log = [];
  const t0 = Date.now();
  const taskData = {
    content: task.content,
    topics: task.topics,
    options: task.options,
    post_url: task.post_url,
    comment: task.comment,
    _btnViewportY: null
  };

  if (!task.ops || !task.ops.length) {
    return { success: false, error: 'no_ops', steps: log };
  }

  // 解码操作码
  const { OPCODES: OPS_MAP } = await import('./opcodes.mjs');
  const steps = task.ops.map(op => ({
    op: OPS_MAP[op.k],
    params: op.p || [],
    delay: op.d || 0
  })).filter(step => step.op);

  for (let i = 0; i < steps.length; i++) {
    const step = steps[i];
    try {
      const r = await executeOp(step.op, step.params, taskData);
      log.push({ step: step.op, ok: r.ok, detail: (r.data || r.error || '').substring(0, 80) });
    } catch (e) {
      log.push({ step: step.op, ok: false, detail: e.message.substring(0, 80) });
    }

    if (step.delay > 0) {
      await humanSleep(step.delay);
    }
  }

  const hasContent = log.some(s => s.step === 'input_content' && s.ok);
  const hasPublished = log.some(s => s.step === 'click_publish' && s.ok);
  const success = hasContent && hasPublished;

  return { success, steps: log, duration_ms: Date.now() - t0 };
}

// ============ 发布后验证与删除 ============

/**
 * 导航到创作者中心,检查最新帖子内容是否正常
 * 返回 { ok: boolean, content: string, issues: string[] }
 */
function verifyPublishedPost(originalContent) {
  // 导航到创作者中心
  run('osascript -e \'tell application "Google Chrome" to tell front window to set URL of active tab to "https://www.binance.com/zh-CN/square/creator-center/content/buzz"\'');
  sleepSync(4000);

  // 获取第一条帖子内容
  const result = js(`(function(){
var items=document.querySelectorAll('.buzz-content-item');
if(!items || items.length===0) return JSON.stringify({ok:false, error:'no_items', content:''});
var text=items[0].textContent || '';
return JSON.stringify({ok:true, content:text.substring(0,500), length:text.length});
})()`);

  let data;
  try {
    data = JSON.parse(result.data || '{}');
  } catch {
    data = { ok: false, error: result.data };
  }

  if (!data.ok) {
    return { ok: false, content: '', issues: ['获取帖子内容失败: ' + (data.error || 'unknown')] };
  }

  const postContent = data.content;
  const issues = [];

  // 检查1: 乱码检测 - 重复的 #标签 碎片(如 "#BT#BTC#B")
  const hashFragmentCount = (postContent.match(/#[A-Za-z\u4e00-\u9fff]{0,2}(?=#|$|\s)/g) || []).length;
  if (hashFragmentCount > 5) {
    issues.push('标签碎片过多(' + hashFragmentCount + '),疑似乱码');
  }

  // 检查2: 重复内容检测 - 同一段文字出现3次以上
  const origLines = originalContent.split('\n').filter(l => l.trim().length > 10);
  let duplicateCount = 0;
  for (const line of origLines) {
    const short = line.substring(0, 20);
    const matches = postContent.split(short).length - 1;
    if (matches >= 3) duplicateCount++;
  }
  if (duplicateCount >= 2) {
    issues.push('内容重复出现3次以上,共' + duplicateCount + '段重复');
  }

  // 检查3: 字符碎片 - 连续单字符(如 "2,8 0" 是数字碎片)
  const fragmentMatch = postContent.match(/[\d,、\s]{8,}/g);
  if (fragmentMatch && fragmentMatch.length >= 2) {
    issues.push('存在数字/标点碎片: ' + fragmentMatch[0].substring(0, 20));
  }

  // 检查4: 话题标签数量异常
  const hashtagCount = (postContent.match(/#[A-Za-z\u4e00-\u9fff]+/g) || []).length;
  if (hashtagCount > 10) {
    issues.push('话题标签过多(' + hashtagCount + '),疑似重复输入');
  }

  // 检查5: 关键宣传行是否存在
  if (originalContent.includes('backtest.CryptoQClaw.ai') && !postContent.includes('backtest.CryptoQClaw.ai')) {
    issues.push('宣传行丢失');
  }

  const ok = issues.length === 0;
  return { ok, content: postContent, issues };
}

/**
 * 删除创作者中心最新的帖子
 * 返回 { ok: boolean, detail: string }
 */
function deleteLatestPost() {
  // 先导航到创作者中心
  run('osascript -e \'tell application "Google Chrome" to tell front window to set URL of active tab to "https://www.binance.com/zh-CN/square/creator-center/content/buzz"\'');
  sleepSync(4000);

  // 用 peekaboo click 移到第一个帖子右下角触发 hover
  const firstItem = js(`(function(){
var items=document.querySelectorAll('.buzz-content-item');
if(!items || !items.length) return JSON.stringify({ok:false});
var r=items[0].getBoundingClientRect();
return JSON.stringify({ok:true, y:Math.round(r.y+r.height-10), x:Math.round(r.x+r.width-20)});
})()`);

  let pos;
  try { pos = JSON.parse(firstItem.data || '{}'); } catch { pos = { ok: false }; }
  if (!pos.ok) return { ok: false, detail: '未找到帖子' };

  // 用 peekaboo click 触发 hover
  if (HAS_PEEKABOO) {
    pk('click', `--global-coords --coords ${pos.x},${pos.y} --app "Google Chrome"`);
  }
  sleepSync(1000);

  // 点击帖子行内的"删除"按钮(w<50,在帖子右侧)
  const clickDel = js(`(function(){
var btns=document.querySelectorAll('button');
for(var i=0;i<btns.length;i++){
  var t=btns[i].textContent.trim();
  var rect=btns[i].getBoundingClientRect();
  if(t==='删除' && rect.width>0 && rect.width<50 && rect.x>1000 && rect.y<400){
    btns[i].click();
    return 'clicked:y='+Math.round(rect.y)+',x='+Math.round(rect.x)+',w='+Math.round(rect.width);
  }
}
return 'not_found';
})()`);

  if ((clickDel.data || '').startsWith('not_found')) {
    return { ok: false, detail: '未找到删除按钮' };
  }
  sleepSync(1000);

  // 点击确认弹窗中的删除按钮(w>100,居中位置)
  const confirmDel = js(`(function(){
var btns=document.querySelectorAll('button');
for(var i=0;i<btns.length;i++){
  var t=btns[i].textContent.trim();
  var rect=btns[i].getBoundingClientRect();
  if(t==='删除' && rect.width>100 && rect.x>500){
    btns[i].click();
    return 'confirmed:y='+Math.round(rect.y)+',x='+Math.round(rect.x)+',w='+Math.round(rect.width);
  }
}
return 'no_confirm';
})()`);

  sleepSync(2000);
  return { ok: (confirmDel.data || '').startsWith('confirmed'), detail: confirmDel.data };
}

/**
 * 编辑创作者中心最新的帖子(修复话题标签等小问题)
 * 1. 点击"编辑"按钮 → 弹出编辑器
 * 2. 在编辑器中修复问题
 * 3. 点击发文保存
 * 返回 { ok: boolean, detail: string }
 */
function editLatestPost(fixes) {
  // fixes: { addTopics: string[], removeGarbage: boolean }
  // 已经在创作者中心页面(由 verifyPublishedPost 导航过了)

  // 1. hover 触发操作按钮
  // 点击第一条帖子右下角触发 hover
  const firstItem = js(`(function(){
var items=document.querySelectorAll('.buzz-content-item');
if(!items || !items.length) return JSON.stringify({ok:false});
var r=items[0].getBoundingClientRect();
return JSON.stringify({ok:true, y:Math.round(r.y+r.height-10), x:Math.round(r.x+r.width-20)});
})()`);
  let pos;
  try { pos = JSON.parse(firstItem.data || '{}'); } catch { pos = { ok: false }; }
  if (pos.ok && HAS_PEEKABOO) {
    pk('click', `--global-coords --coords ${pos.x},${pos.y} --app "Google Chrome"`);
  }
  sleepSync(1000);

  // 点击"编辑"按钮
  const editClicked = js(`(function(){
var btns=document.querySelectorAll('button');
for(var i=0;i<btns.length;i++){
  var t=btns[i].textContent.trim();
  var rect=btns[i].getBoundingClientRect();
  if((t==='编辑'||t==='Edit') && rect.width>0 && rect.width<50 && rect.x>800 && rect.y<400){
    btns[i].click();
    return 'clicked:y='+Math.round(rect.y)+',x='+Math.round(rect.x);
  }
}
return 'not_found';
})()`);
  sleepSync(3000);

  if ((editClicked.data || '').startsWith('not_found')) {
    return { ok: false, detail: '未找到编辑按钮: ' + editClicked.data };
  }
  console.log('  ✏️ 点击编辑按钮: ' + editClicked.data);

  // 2. 等待编辑器加载
  sleepSync(2000);
  // 检查编辑器是否出现
  const pmCheck = js('(function(){var pm=document.querySelector(".ProseMirror"); return pm?"ok:len="+pm.textContent.length:"no_pm";})()');
  if ((pmCheck.data || '').startsWith('no_pm')) {
    return { ok: false, detail: '编辑器未出现' };
  }
  console.log('  ✏️ 编辑器已加载: ' + pmCheck.data);

  // 3. 修复:移除垃圾文本(如果有)
  if (fixes.removeGarbage) {
    // 移除末尾的乱码标签碎片(#后面跟着少量字符又接#的模式)
    js(`(function(){
var pm=document.querySelector('.ProseMirror');
if(!pm) return 'no_pm';
var html=pm.innerHTML;
// 移除纯文本中的乱码标签碎片(非 richtext-hashtag 的 # 文字)
html=html.replace(/\s*#[A-Za-z\u4e00-\u9fff]{0,3}(?=[#\s]|$)/g, '');
pm.innerHTML=html;
pm.dispatchEvent(new Event('input',{bubbles:true}));
return 'cleaned';
})()`);
    sleepSync(1000);
    console.log('  🧹 清理垃圾标签');
  }

  // 4. 修复:添加缺失的话题标签
  if (fixes.addTopics && fixes.addTopics.length > 0) {
    // 把光标移到编辑器末尾
    js("(function(){var pm=document.querySelector('.ProseMirror'); if(!pm) return; pm.focus(); var r=document.createRange(); r.selectNodeContents(pm); r.collapse(false); var s=window.getSelection(); s.removeAllRanges(); s.addRange(r); return 'cursor_end';})()");
    sleepSync(500);

    for (const topic of fixes.addTopics) {
      const tag = ' #' + topic;
      const esc = tag.replace(/\\/g,'\\\\').replace(/`/g,'\\`').replace(/\$/g,'\\$');
      js(`(function(){document.execCommand('insertText',false,\`${esc}\`); return 'OK';})()`);
      sleepSync(3000);
      // 点击下拉框第一项
      js("(function(){var sug=document.querySelector('.editor-suggestion'); if(!sug) return; var items=sug.querySelectorAll(':scope > div'); if(items.length) items[0].click();})()");
      sleepSync(1500);
      console.log(`  🏷️ 添加标签 #${topic}`);
    }
  }

  // 5. 点击发文按钮保存编辑
  sleepSync(1000);
  const btnResult = findPublishButton();
  const yMatch = (btnResult.data || '').match(/y=(\d+)/);
  if (!yMatch) {
    return { ok: false, detail: '编辑器中未找到发文按钮' };
  }
  const publishResult = clickPublishBtn(parseInt(yMatch[1]));
  sleepSync(3000);
  console.log('  ✏️ 编辑保存: ' + (publishResult.data || ''));

  return { ok: true, detail: 'edited_and_saved: ' + (publishResult.data || '') };
}

// ============ 简易发布(无需操作码,兼容旧 API) ============

/**
 * 简易发布流程 - 从服务器拿到内容直接发布
 * 用于没有 ops 序列的旧式任务
 * 含发布后验证:检查内容是否正常,异常时删除重试
 */
async function simplePublish(content, topics, _retryCount = 0) {
  const log = [];
  const t0 = Date.now();

  try {
    // 1. 检查 Chrome
    const chromeCheck = run('pgrep -x "Google Chrome"');
    if (!chromeCheck.ok) {
      return { success: false, error: 'Chrome 未运行', steps: log, duration_ms: Date.now() - t0 };
    }

    // 2. 检查 peekaboo
    const peekabooCheck = run('which peekaboo');
    const hasPeekaboo = peekabooCheck.ok;
    log.push({ step: 'check_deps', ok: true, detail: `chrome=ok peekaboo=${hasPeekaboo}` });

    // 检测是否是投票内容
    const pollOptions = extractPollOptions(content);
    const isPoll = pollOptions.length >= 2;
    if (isPoll) {
      console.log(`  📊 检测到投票内容,${pollOptions.length} 个选项: ${pollOptions.join(', ')}`);
    }

    // 3. 导航到广场(投票模式先强制刷新,清除残留 UI)
    if (isPoll) {
      // CDP 模式:用 Page.navigate 强制完整刷新
      if (isCdpAvailable()) {
        try {
          run(`curl -s http://127.0.0.1:${CDP_PORT}/json/list`);
          // 通过 AppleScript 导航 + 强制刷新
          run(`osascript -e 'tell application "Google Chrome" to tell window 1 to set URL of active tab to "https://www.binance.com/zh-CN/square"'`);
          await sleep(2000);
          // 强制刷新
          js('window.location.reload()');
          await sleep(5000);
        } catch(e) {
          await navigateToSquare();
        }
      } else {
        await navigateToSquare();
        await sleep(1000);
        js('window.location.reload()');
        await sleep(5000);
      }
    } else {
      await navigateToSquare();
    }
    log.push({ step: 'navigate', ok: true, detail: isPoll ? 'square+refresh' : 'square' });

    // 3.5 等待 ProseMirror 编辑器出现(最多 20 秒)
    let pmReady = false;
    for (let i = 0; i < 10; i++) {
      const pmCheck = js('(function(){var pm=document.querySelector(".ProseMirror"); return pm?"yes":"no";})()');
      if ((pmCheck.data || '') === 'yes') { pmReady = true; break; }
      console.log(`  ⏳ 等待编辑器... (${i + 1}/10)`);
      await sleep(2000);
    }
    log.push({ step: 'wait_pm', ok: pmReady, detail: pmReady ? 'editor_loaded' : 'timeout' });
    if (!pmReady) {
      return { success: false, error: '编辑器未加载', steps: log, duration_ms: Date.now() - t0 };
    }

    // 4. 最大化 Chrome 窗口(按钮坐标依赖窗口大小)
    maximizeWindow();
    log.push({ step: 'maximize', ok: true, detail: '1920x1080' });

    // 5. 展开编辑器
    await expandEditor();
    log.push({ step: 'expand', ok: true, detail: 'editor' });

    // 5.5 隐藏 chat iframe（投票帖点击需要，否则 iframe 拦截点击事件）
    if (isPoll) {
      js("(function(){var ifs=document.querySelectorAll('iframe'); for(var i=0;i<ifs.length;i++){if(ifs[i].src&&ifs[i].src.indexOf('chatWidget')>=0) ifs[i].style.display='none';} return 'ok';})()");
      log.push({ step: 'hide_chat_iframe', ok: true, detail: 'done' });
    }
    await humanSleep(1000);

    // 6. 聚焦编辑器
    const focusResult = focusEditor();
    log.push({ step: 'focus', ok: focusResult.ok, detail: focusResult.data || focusResult.error });
    await humanSleep(500);

    if (isPoll) {
      // === 投票模式 ===
      // 只输入投票问题部分(去掉 A) B) 选项行)
      const questionContent = content.split('\n').filter(line => {
        return !/^[A-Z]\)\s/.test(line.trim()) && !/^[1-9]️⃣\s/.test(line.trim());
      }).join('\n');
      const cleanContent = questionContent.replace(/\n{3,}/g, '\n\n').trim();

      // 输入问题内容(必须极短,保持工具栏在默认位置)
      const shortContent = cleanContent.split('\n').slice(0, 3).join('\n');
      const inputResult = insertTextViaExec(shortContent);
      log.push({ step: 'input_question', ok: inputResult.ok, detail: inputResult.data || inputResult.error });
      await humanSleep(1500);

      // 记录 Chrome 窗口偏移
      const offset = getChromeOffset();
      log.push({ step: 'chrome_offset', ok: true, detail: JSON.stringify(offset) });

      // 检测 CDP 可用性
      const useCdp = isCdpAvailable();
      log.push({ step: 'cdp_check', ok: true, detail: `cdp=${useCdp} port=${CDP_PORT}` });
      console.log(`  🔌 CDP 状态: ${useCdp ? '可用' : '不可用'} (port ${CDP_PORT})`);

      // offset 异常时直接跳过投票,回退为普通帖子
      if (!offset.valid) {
        log.push({ step: 'more_btn', ok: false, detail: 'Chrome窗口异常,跳过投票' });
        clearEditor();
        await humanSleep(500);
        insertTextViaExec(content);
        log.push({ step: 'fallback_input', ok: true, detail: 'full_content_window_invalid' });

      } else if (useCdp) {
        // =====================================================
        // CDP + CGEvent 流程(React 只响应 OS 级别真实点击)
        // =====================================================

        // === 第1步:CGEvent 点击"更多"按钮 ===
        const moreBtnPos = js(`(function(){var el=document.getElementById('post-editor-more-icon'); if(!el) return 'not_found'; var r=el.getBoundingClientRect(); return Math.round(r.x+r.width/2)+','+Math.round(r.y+r.height/2);})()`);
        log.push({ step: 'find_more_btn', ok: true, detail: moreBtnPos.data || moreBtnPos.error });

        const moreMatch = (moreBtnPos.data || '').match(/^(\d+),(\d+)$/);
        if (!moreMatch) {
          log.push({ step: 'more_btn', ok: false, detail: '未找到更多按钮(post-editor-more-icon),回退为普通帖子' });
          clearEditor();
          await humanSleep(500);
          insertTextViaExec(content);
          log.push({ step: 'fallback_input', ok: true, detail: 'no_more_btn' });
        } else {
          const vpX = parseInt(moreMatch[1]);
          const vpY = parseInt(moreMatch[2]);
          const gX = vpX + offset.screen_x;
          const gY = vpY + offset.screen_y + offset.ui_height;

          console.log(`  🖱️ CGEvent click 更多: viewport(${vpX},${vpY}) → global(${gX},${gY})`);
          const clickMore = cgClick(gX, gY);
          log.push({ step: 'click_more', ok: clickMore.ok, detail: `global=${gX},${gY} cdp_mode` });
          await humanSleep(2500);

          // === 第2步:CGEvent 点击"创建投票" ===
          let voteClicked = false;
          for (let retry = 0; retry < 5; retry++) {
            const voteBtnPos = js(`(function(){var all=document.querySelectorAll('*'); for(var i=0;i<all.length;i++){var t=(all[i].textContent||'').trim(); if(t==='创建投票'){var r=all[i].getBoundingClientRect(); if(r.width>0&&r.width<200) return Math.round(r.x+r.width/2)+','+Math.round(r.y+r.height/2);}} return 'not_found';})()`);
            if ((voteBtnPos.data || '').match(/^\d+,\d+$/)) {
              const [vx, vy] = voteBtnPos.data.split(',').map(Number);
              const gvX = vx + offset.screen_x;
              const gvY = vy + offset.screen_y + offset.ui_height;
              console.log(`  🖱️ CGEvent click 创建投票: global(${gvX},${gvY})`);
              cgClick(gvX, gvY);
              voteClicked = true;
              log.push({ step: 'create_poll', ok: true, detail: `global=${gvX},${gvY} retry=${retry}` });
              break;
            }
            console.log(`  ⏳ 等待创建投票菜单... (${retry + 1}/5)`);
            await sleep(1000);
          }

          if (!voteClicked) {
            log.push({ step: 'create_poll', ok: false, detail: 'not_found' });
            console.log('  ⚠️ 投票创建失败,回退为普通帖子');
            clearEditor();
            await humanSleep(500);
            insertTextViaExec(content);
            log.push({ step: 'fallback_input', ok: true, detail: 'poll_create_failed' });
          } else {
            await humanSleep(2000);

            // === 第3步:填写投票选项(JS focus + CDP Input.insertText) ===
            for (let oi = 0; oi < pollOptions.length && oi < 4; oi++) {
              // 用 JS focus() 聚焦第 oi 个选项输入框(比 CGEvent 点击更可靠)
              const focusResult = js(`(function(){var inputs=document.querySelectorAll('input'); var opts=[]; for(var i=0;i<inputs.length;i++){var ph=inputs[i].getAttribute('placeholder')||''; if(ph.indexOf('选项')>=0){opts.push(inputs[i]);}} opts.sort(function(a,b){return a.getBoundingClientRect().y - b.getBoundingClientRect().y;}); if(${oi}>=opts.length) return 'not_found'; opts[${oi}].focus(); opts[${oi}].click(); return 'focused y='+Math.round(opts[${oi}].getBoundingClientRect().y);})()`);

              if ((focusResult.data || '').startsWith('focused')) {
                await sleep(400);

                // CDP Input.insertText 填写选项文本
                const cdpRes = await cdpInsertText(pollOptions[oi]);
                console.log(`  ⌨️ 选项${oi + 1}: "${pollOptions[oi]}" → ${cdpRes.ok ? 'ok' : cdpRes.error}`);
                log.push({ step: `fill_option_${oi}`, ok: cdpRes.ok, detail: `${pollOptions[oi]} via_js_focus+cdp` });
              } else {
                log.push({ step: `fill_option_${oi}`, ok: false, detail: `input_not_found: ${focusResult.data || focusResult.error}` });
              }
              await humanSleep(500);
            }
          }
        }

      } else {
        // =====================================================
        // Peekaboo/AppleScript 回退流程(CDP 不可用时)
        // =====================================================

        // === 第1步：点击"更多"按钮 ===
        // 优先用 post-editor-more-icon ID，回退到 icon-box
        const moreBtnPos = js(`(function(){var el=document.getElementById('post-editor-more-icon'); if(el){var r=el.getBoundingClientRect(); if(r.width>0) return Math.round(r.x+r.width/2)+','+Math.round(r.y+r.height/2);} var icons=document.querySelectorAll('[class*=icon-box]'); for(var i=icons.length-1;i>=0;i--){var rect=icons[i].getBoundingClientRect(); if(rect.y>400&&rect.y<460&&rect.x>740&&rect.x<770){return Math.round(rect.x+rect.width/2)+','+Math.round(rect.y+rect.height/2);}} return 'not_found';})()`);
        log.push({ step: 'find_more_btn', ok: true, detail: moreBtnPos.data || moreBtnPos.error });

        const moreMatch = (moreBtnPos.data || '').match(/^(\d+),(\d+)$/);
        if (!moreMatch) {
          log.push({ step: 'more_btn', ok: false, detail: '未找到更多按钮,回退为普通帖子' });
          clearEditor();
          await humanSleep(500);
          insertTextViaExec(content);
          log.push({ step: 'fallback_input', ok: true, detail: 'full_content' });
        } else {
          const vpX = parseInt(moreMatch[1]);
          const vpY = parseInt(moreMatch[2]);
          const gX = vpX;
          const gY = offset.screen_y + offset.ui_height + vpY;

          if (HAS_PEEKABOO) {
            pk('click', `--global-coords --coords ${gX},${gY} --app "Google Chrome"`);
          } else {
            run(`osascript -e 'tell application "System Events" to click at {${gX}, ${gY}}'`);
          }
          log.push({ step: 'click_more', ok: true, detail: `global=${gX},${gY} peekaboo=${HAS_PEEKABOO}` });
          await humanSleep(2500);

          // === 第2步:点击"创建投票" ===
          let voteClicked = false;
          for (let retry = 0; retry < 5; retry++) {
            const voteBtnPos = js(`(function(){var all=document.querySelectorAll('*'); for(var i=0;i<all.length;i++){var t=(all[i].textContent||'').trim(); if(t==='创建投票'){var r=all[i].getBoundingClientRect(); if(r.width>0&&r.width<200) return Math.round(r.x+r.width/2)+','+Math.round(r.y+r.height/2);}} return 'not_found';})()`);
            if ((voteBtnPos.data || '').match(/^\d+,\d+$/)) {
              const [vx, vy] = voteBtnPos.data.split(',').map(Number);
              const gvY = offset.screen_y + offset.ui_height + vy;
              if (HAS_PEEKABOO) {
                pk('click', `--global-coords --coords ${vx},${gvY} --app "Google Chrome"`);
              } else {
                run(`osascript -e 'tell application "System Events" to click at {${vx}, ${gvY}}'`);
              }
              voteClicked = true;
              log.push({ step: 'create_poll', ok: true, detail: `global=${vx},${gvY} retry=${retry}` });
              break;
            }
            console.log(`  ⏳ 等待创建投票菜单... (${retry + 1}/5)`);
            await sleep(1000);
          }

          if (!voteClicked) {
            log.push({ step: 'create_poll', ok: false, detail: 'not_found' });
            console.log('  ⚠️ 投票创建失败,回退为普通帖子');
            clearEditor();
            await humanSleep(500);
            insertTextViaExec(content);
            log.push({ step: 'fallback_input', ok: true, detail: 'full_content_after_poll_fail' });
          }

          await humanSleep(2000);

          // === 第3步：填写投票选项（JS focus + peekaboo type）===
          if (voteClicked) {
            for (let oi = 0; oi < pollOptions.length && oi < 4; oi++) {
              // 用 JS focus() 聚焦第 oi 个选项输入框（比 CGEvent 点击更可靠）
              const focusResult = js(`(function(){var inputs=document.querySelectorAll('input'); var opts=[]; for(var i=0;i<inputs.length;i++){var ph=inputs[i].getAttribute('placeholder')||''; if(ph.indexOf('选项')>=0){opts.push(inputs[i]);}} opts.sort(function(a,b){return a.getBoundingClientRect().y - b.getBoundingClientRect().y;}); if(${oi}>=opts.length) return 'not_found'; opts[${oi}].focus(); opts[${oi}].click(); return 'focused y='+Math.round(opts[${oi}].getBoundingClientRect().y);})()`);

              if ((focusResult.data || '').startsWith('focused')) {
                await humanSleep(400);
                if (HAS_PEEKABOO) {
                  pk('type', `"${pollOptions[oi]}" --app "Google Chrome"`);
                } else {
                  js(`(function(){var inputs=document.querySelectorAll('input'); var opts=[]; for(var i=0;i<inputs.length;i++){var ph=inputs[i].getAttribute('placeholder')||''; if(ph.indexOf('选项')>=0){opts.push(inputs[i]);}} opts.sort(function(a,b){return a.getBoundingClientRect().y - b.getBoundingClientRect().y;}); if(${oi}<opts.length){var s=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set; s.call(opts[${oi}],'${pollOptions[oi].replace(/'/g, "\\'")}'); opts[${oi}].dispatchEvent(new Event('input',{bubbles:true})); opts[${oi}].dispatchEvent(new Event('change',{bubbles:true})); return 'filled';} return 'no_input';})()`);
                }
                console.log(`  ⌨️ 选项${oi + 1}: "${pollOptions[oi]}" → ok`);
                log.push({ step: `fill_option_${oi}`, ok: true, detail: `${pollOptions[oi]} via_js_focus+pk_type` });
              } else {
                log.push({ step: `fill_option_${oi}`, ok: false, detail: `input_not_found: ${focusResult.data || focusResult.error}` });
              }
              await humanSleep(500);
            }
          }
        }
      }

      // 聚焦回编辑器
      focusEditor();
      await humanSleep(500);

    } else {
      // === 普通帖子模式(innerHTML + <p> 标签,发文按钮可用)===
      const inputResult = insertTextViaExec(content);
      log.push({ step: 'input', ok: inputResult.ok, detail: inputResult.data || inputResult.error });
      await humanSleep(1500);
      // 确保 React 状态更新,发文按钮激活
      js("(function(){var pm=document.querySelector('.ProseMirror'); if(pm) pm.dispatchEvent(new Event('input',{bubbles:true})); return 'ok';})()");
      await humanSleep(500);
    }

    // 添加话题
    if (topics && topics.length > 0) {
      await addTopics(topics);
      log.push({ step: 'topics', ok: true, detail: topics.join(',') });
      await humanSleep(1000);
    }

    // 查找发布按钮
    const btnResult = findPublishButton();
    log.push({ step: 'find_btn', ok: btnResult.ok, detail: btnResult.data || btnResult.error });

    const yMatch = (btnResult.data || '').match(/y=(\d+)/);
    if (!yMatch) {
      const debugBtns = js(`(function(){var btns=document.querySelectorAll('button');var r=[];for(var i=0;i<btns.length;i++){var t=btns[i].textContent.trim();var rect=btns[i].getBoundingClientRect();if(rect.width>0&&t)r.push(t+':x='+Math.round(rect.x)+',y='+Math.round(rect.y)+',w='+Math.round(rect.width));}return r.join('|');})()`);
      return { success: false, error: '未找到发布按钮 (buttons: ' + (debugBtns.data || debugBtns.error || 'none') + ')', steps: log, duration_ms: Date.now() - t0 };
    }

    // 点击发布
    const publishResult = clickPublishBtn(parseInt(yMatch[1]));
    log.push({ step: 'publish', ok: publishResult.ok, detail: publishResult.data || publishResult.error });
    await humanSleep(3000);

    // 验证发布成功(检查 ProseMirror 是否消失 = 内容已清空)
    const verifyResult = js('(function(){var pm=document.querySelector(".ProseMirror"); if(!pm) return "no_pm"; var len=pm.textContent.length; return len<5?"published":"still_has_content_len="+len;})()');
    log.push({ step: 'verify_publish', ok: true, detail: verifyResult.data || 'unknown' });

    // ===== 发布后检查:到创作者中心验证内容 =====
    if (_retryCount < 2) {
      console.log('  🔍 发布后检查中...');
      const check = verifyPublishedPost(content);
      log.push({ step: 'post_check', ok: check.ok, detail: check.ok ? '内容正常' : check.issues.join('; ') });

      if (!check.ok) {
        // 分类问题:小问题可编辑修复,大问题需删除重试
        const minorIssues = check.issues.filter(i =>
          i.includes('标签碎片') ||
          i.includes('标签过多') ||
          i.includes('宣传行丢失')
        );
        const majorIssues = check.issues.filter(i =>
          i.includes('内容重复') ||
          i.includes('数字/标点碎片')
        );

        console.log('  ⚠️ 问题分类: 小问题=' + minorIssues.length + ', 大问题=' + majorIssues.length);

        // 小问题:编辑修复(添加缺失标签、清理乱码标签)
        if (minorIssues.length > 0 && majorIssues.length === 0) {
          console.log('  ✏️ 小问题,尝试编辑修复...');
          // 判断需要添加哪些标签
          const postContent = check.content || '';
          const missingTopics = (topics || []).filter(t => !postContent.includes(t));
          const editResult = editLatestPost({
            addTopics: missingTopics,
            removeGarbage: check.issues.some(i => i.includes('标签碎片') || i.includes('标签过多'))
          });
          log.push({ step: 'edit_fix', ok: editResult.ok, detail: editResult.detail });
          if (editResult.ok) {
            console.log('  ✅ 编辑修复成功');
          } else {
            console.log('  ⚠️ 编辑修复失败: ' + editResult.detail);
          }
        }

        // 大问题:删除 + 重试
        if (majorIssues.length > 0 && _retryCount < 1) {
          console.log('  🗑️ 大问题(内容乱码),删除重试...');
          const delResult = deleteLatestPost();
          log.push({ step: 'delete_bad_post', ok: delResult.ok, detail: delResult.detail });

          if (delResult.ok) {
            await sleep(3000);
            console.log('  🔄 重新发布 (retry=' + (_retryCount + 1) + ')...');
            const retryResult = await simplePublish(content, topics, _retryCount + 1);
            retryResult.steps = [...log, ...retryResult.steps];
            retryResult.duration_ms = Date.now() - t0;
            return retryResult;
          } else {
            log.push({ step: 'retry', ok: false, detail: '删除失败,无法重试' });
          }
        }

        // 大问题但已达重试上限
        if (majorIssues.length > 0 && _retryCount >= 1) {
          log.push({ step: 'retry_limit', ok: false, detail: '已达最大重试次数' });
        }
      } else {
        console.log('  ✅ 发布后检查通过');
      }
    } else {
      log.push({ step: 'post_check', ok: true, detail: 'skipped(max_retry)' });
    }

    return {
      success: true,
      postId: `post_${Date.now()}`,
      steps: log,
      duration_ms: Date.now() - t0
    };
  } catch (err) {
    return { success: false, error: err.message, steps: log, duration_ms: Date.now() - t0 };
  }
}

/**
 * 从内容中提取投票选项
 * 支持 A) xxx / B) xxx 和 1️⃣ xxx / 2️⃣ xxx 格式
 */
function extractPollOptions(content) {
  const options = [];
  const lines = content.split('\n');
  for (const line of lines) {
    const trimmed = line.trim();
    // 匹配 A) xxx / B) xxx
    const letterMatch = trimmed.match(/^[A-Z]\)\s+(.+)/);
    if (letterMatch) {
      // 去掉末尾 emoji
      options.push(letterMatch[1].replace(/\s*[🚀📉➡️🤔📈🧘🐻🐂⚡🎯📋😴✅].*$/, '').trim());
      continue;
    }
    // 匹配 1️⃣ xxx / 2️⃣ xxx
    const numMatch = trimmed.match(/^[12]️⃣\s+(.+)/);
    if (numMatch) {
      options.push(numMatch[1].replace(/\s*[---].+$/, '').trim());
    }
  }
  return options;
}

// ============ 主循环 ============

// ============ 自动更新 ============
const AGENT_PATH = new URL(import.meta.url).pathname;

async function checkUpdate() {
  try {
    const res = await fetch(`${SERVER_URL}/api/agent/version`, {
      headers: { 'X-API-Key': API_KEY }
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data; // { version, hash, size }
  } catch {
    return null;
  }
}

async function selfUpdate() {
  const info = await checkUpdate();
  if (!info) return false;

  // 用文件大小判断是否需要更新(简单可靠)
  const stat = existsSync(AGENT_PATH) ? readFileSync(AGENT_PATH).length : 0;
  if (info.size && Math.abs(info.size - stat) < 10) return false; // 大小一样,跳过

  console.log(`🔄 发现新版本 (remote: ${info.size}B, local: ${stat}B),更新中...`);
  const res = await fetch(`${SERVER_URL}/download/agent`);
  if (!res.ok) return false;
  const newCode = await res.text();
  writeFileSync(AGENT_PATH, newCode);
  console.log(`✅ 已更新 (${newCode.length} bytes),重启中...`);
  // 重启自己
  process.exit(0); // launchd KeepAlive 会自动重启
}

async function main() {
  // === 单进程锁 ===
  const LOCK_FILE = '/tmp/square-agent.lock';
  try {
    const pid = readFileSync(LOCK_FILE, 'utf8').trim();
    // 检查该 PID 是否是 square-agent 进程
    const check = run(`ps -p ${pid} -o command=`);
    if (check.ok && check.data.includes('square-agent')) {
      console.error(`❌ 另一个 agent 进程已在运行 (PID ${pid}),退出`);
      process.exit(1);
    }
    // PID 不存在或不是 agent 进程,清理旧锁
    console.log(`  🧹 清理旧锁文件 (旧 PID ${pid})`);
  } catch {}
  // 写入当前 PID
  writeFileSync(LOCK_FILE, String(process.pid));
  // 退出时清理锁
  process.on('exit', () => { try { execSync('rm -f ' + LOCK_FILE); } catch {} });
  process.on('SIGINT', () => process.exit(0));
  process.on('SIGTERM', () => process.exit(0));

  console.log('🤖 Binsquare Agent v0.2.0');
  console.log(`📡 Server: ${SERVER_URL}`);

  // 自动检查更新(禁用:本地有自定义修改)
  // await selfUpdate();

  // 检查依赖
  const chromeCheck = run('pgrep -x "Google Chrome"');
  if (!chromeCheck.ok) {
    console.warn('⚠️  Chrome 未运行,请在开始发布前打开 Chrome 并登录币安');
  }

  const peekabooCheck = run('which peekaboo');
  if (!peekabooCheck.ok) {
    console.warn('⚠️  Peekaboo 未安装,部分功能不可用');
    console.warn('   安装: brew install steipete/tap/peekaboo');
  } else {
    console.log('✅ Peekaboo: 已安装');
  }

  try {
    await register();
  } catch (err) {
    console.error(`❌ 注册失败: ${err.message}`);
    process.exit(1);
  }

  setInterval(heartbeat, 60000);

  console.log(`🔄 轮询中(间隔 ${POLL_INTERVAL / 1000}s)...`);
  console.log('');

  let pollCount = 0;
  let skipCount = 0;
  while (true) {
    pollCount++;
    const mode = (() => { try { return readFileSync(join(homedir(), 'clawd/data/binance-content/.chrome-mode'), 'utf8').trim(); } catch { return 'cron'; } })();
    if (mode !== 'agent') {
      skipCount++;
      if (skipCount % 20 === 1) console.log(`[${ts()}] ⏸️ Chrome mode=${mode}, waiting...`);
      await sleep(POLL_INTERVAL);
      continue;
    }
    skipCount = 0;
    try {
      const posts = await fetchPending();
      // 防重复:跳过已发布过的帖子
      const newPosts = (posts || []).filter(p => !publishedSet.has(p.id));
      if (newPosts.length < (posts || []).length) {
        console.log(`[${ts()}] ⚠️ 跳过 ${((posts||[]).length - newPosts.length)} 条已发布帖子`);
      }
      const postsToPublish = newPosts;
      if (posts && posts.length > 0) {
        console.log(`\n[${ts()}] 📨 收到 ${posts.length} 条待发布内容`);
        for (const post of postsToPublish) {
          console.log(`[${ts()}] 📝 发布中 #${post.id} (${post.type || 'post'})...`);

          let result;
          if (post.ops && post.ops.length > 0) {
            // 有操作码序列 → 用操作码引擎执行
            result = await executeOpsTask(post);
          } else {
            // 无操作码 → 简易发布
            result = await simplePublish(post.content, post.topics);
          }

          if (result.success) {
            console.log(`[${ts()}] ✅ #${post.id} 发布成功 (${result.duration_ms}ms)`);
            await reportStatus(post.id, 'published', result.postId, null, result.steps);
            publishedSet.add(post.id);
          } else {
            console.error(`[${ts()}] ❌ #${post.id} 发布失败: ${result.error}`);
            await reportStatus(post.id, 'failed', undefined, result.error, result.steps);
            // 失败也加入集合,防止反复重试同一个帖子
            publishedSet.add(post.id);
          }

          // 写日志
          writeLog(post, result);
        }
      } else {
        if (pollCount % 20 === 0) {
          console.log(`[${ts()}] 💓 idle (${pollCount} polls)`);
        }
      }
    } catch (err) {
      console.error(`[${ts()}] ⚠️ Error: ${err.message}`);
    }
    await sleep(POLL_INTERVAL);
  }
}

main();
