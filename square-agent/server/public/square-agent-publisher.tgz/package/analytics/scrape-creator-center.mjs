#!/usr/bin/env node
// SquareAgent - Scrape Binance Creator Center Stats
// Uses Peekaboo + Chrome to extract post performance data
// Run this BEFORE engagement-analysis.mjs for full data
//
// Usage:
//   node scrape-creator-center.mjs           # Scrape and save
//   node scrape-creator-center.mjs --json    # Output JSON only

import { execSync } from 'child_process';
import { writeFileSync, existsSync, mkdirSync } from 'fs';
import { join } from 'path';
import { homedir } from 'os';

const DATA_DIR = join(homedir(), 'clawd/data/binance-content/analytics');
if (!existsSync(DATA_DIR)) mkdirSync(DATA_DIR, { recursive: true });
const today = new Date().toISOString().slice(0, 10);
const outputJson = process.argv.includes('--json');

const PEEKABOO = '/opt/homebrew/bin/peekaboo';
const TIMEOUT = 60000;

function peekaboo(cmd) {
  try {
    return execSync(`${PEEKABOO} ${cmd}`, { encoding: 'utf8', timeout: TIMEOUT });
  } catch (e) {
    return null;
  }
}

function chromeExec(js) {
  try {
    const result = execSync(
      `osascript -l JavaScript -e 'Application("Google Chrome").windows[0].activeTab().execute({javascript: ${JSON.stringify(js)}})'`,
      { encoding: 'utf8', timeout: 30000 }
    );
    return result.trim();
  } catch (e) {
    return null;
  }
}

// Step 1: Navigate to creator center
console.log('Navigating to creator center...');
peekaboo(`navigate "https://www.binance.com/zh-CN/square/creator-center/home"`);
execSync('sleep 5');

// Step 2: Scrape follower count and overall stats
console.log('Scraping stats...');
const statsResult = chromeExec(`
  (function() {
    const text = document.body.innerText;
    const results = {};
    
    // Try to find follower count
    const followerMatch = text.match(/粉丝[\\s]*(\\d+)/);
    if (followerMatch) results.followers = parseInt(followerMatch[1]);
    
    // Try to find following count
    const followingMatch = text.match(/关注[\\s]*(\\d+)/);
    if (followingMatch) results.following = parseInt(followingMatch[1]);
    
    // Try to find total likes
    const likesMatch = text.match(/获赞[\\s]*(\\d+)/);
    if (likesMatch) results.totalLikes = parseInt(likesMatch[1]);
    
    // Find 7-day data section
    const viewsMatch = text.match(/浏览量[\\s:]*(\\d[\\d,]*)/);
    if (viewsMatch) results.weeklyViews = parseInt(viewsMatch[1].replace(/,/g, ''));
    
    return JSON.stringify(results);
  })()
`);

let stats = {};
if (statsResult) {
  try { stats = JSON.parse(statsResult); } catch {}
}

// Step 3: Try to scrape individual post data from content management tab
console.log('Scraping post data...');
// Navigate to content management
peekaboo(`navigate "https://www.binance.com/zh-CN/square/creator-center/content"`);
execSync('sleep 5');

const postsResult = chromeExec(`
  (function() {
    const posts = [];
    // Try to find post cards/rows
    const rows = document.querySelectorAll('[class*="post"], [class*="content-item"], [class*="article"]');
    rows.forEach((row, i) => {
      if (i >= 20) return; // Limit to 20 posts
      const text = row.innerText;
      const titleMatch = text.match(/^(.{5,60})\\n/);
      const viewsMatch = text.match(/(\\d[\\d,]*)\\s*浏览/);
      const likesMatch = text.match(/(\\d+)\\s*赞/);
      const commentsMatch = text.match(/(\\d+)\\s*评论/);
      
      if (titleMatch || viewsMatch) {
        posts.push({
          title: titleMatch ? titleMatch[1].trim() : '',
          views: viewsMatch ? parseInt(viewsMatch[1].replace(/,/g, '')) : 0,
          likes: likesMatch ? parseInt(likesMatch[1]) : 0,
          comments: commentsMatch ? parseInt(commentsMatch[1]) : 0,
        });
      }
    });
    return JSON.stringify(posts);
  })()
`);

let postsData = [];
if (postsResult) {
  try { postsData = JSON.parse(postsResult); } catch {}
}

// Step 4: Compile and save
const result = {
  date: today,
  scrapedAt: new Date().toISOString(),
  ...stats,
  posts: postsData,
};

const outputFile = join(DATA_DIR, `creator-stats-${today}.json`);
writeFileSync(outputFile, JSON.stringify(result, null, 2));

if (outputJson) {
  console.log(JSON.stringify(result, null, 2));
} else {
  console.log(`✅ Creator center stats saved: ${outputFile}`);
  console.log(`Followers: ${stats.followers || 'N/A'} | Posts scraped: ${postsData.length}`);
  console.log(`Now run: node ~/.square-agent-publisher/analytics/engagement-analysis.mjs`);
}
