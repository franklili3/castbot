#!/usr/bin/env node
// SquareAgent - Telegram Notification Helper
// Sends messages via @Square_AgentBot to the configured chat
//
// Usage:
//   node telegram-notify.mjs "message text"
//   node telegram-notify.mjs --file /path/to/report.md
//   echo "message" | node telegram-notify.mjs --stdin

import { execSync } from 'child_process';
import { readFileSync } from 'fs';
import { loadEnvFile } from 'process';

// Load .env
loadEnvFile('/Users/mac/clawd/data/.env');

const BOT_TOKEN = process.env.telegram_square_agent_bot_token;
const CHAT_ID = process.env.telegram_square_agent_chat_id;
const PROXY = 'http://127.0.0.1:7890';

if (!BOT_TOKEN || !CHAT_ID) {
  console.error('Missing telegram_square_agent_bot_token or telegram_square_agent_chat_id in .env');
  process.exit(1);
}

// Get message from args, file, or stdin
let message = '';
const args = process.argv.slice(2);

if (args.includes('--stdin')) {
  message = readFileSync('/dev/stdin', 'utf8');
} else if (args.includes('--file')) {
  const idx = args.indexOf('--file');
  const filePath = args[idx + 1];
  if (filePath) message = readFileSync(filePath, 'utf8');
} else if (args.length > 0) {
  message = args.join(' ');
} else {
  console.error('Usage: node telegram-notify.mjs "message" | --file path | --stdin');
  process.exit(1);
}

if (!message.trim()) {
  console.error('Empty message');
  process.exit(1);
}

// Telegram message limit is 4096 chars
const chunks = [];
if (message.length > 4000) {
  // Split by lines, keeping each chunk under 4000
  const lines = message.split('\n');
  let current = '';
  for (const line of lines) {
    if ((current + '\n' + line).length > 4000) {
      chunks.push(current);
      current = line;
    } else {
      current = current ? current + '\n' + line : line;
    }
  }
  if (current) chunks.push(current);
} else {
  chunks.push(message);
}

let successCount = 0;
for (const chunk of chunks) {
  const encoded = encodeURIComponent(chunk);
  const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage?chat_id=${CHAT_ID}&text=${encoded}&parse_mode=HTML`;
  
  try {
    const result = execSync(`curl -s --proxy ${PROXY} "${url}"`, { encoding: 'utf8', timeout: 30000 });
    const resp = JSON.parse(result);
    if (resp.ok) {
      successCount++;
    } else {
      console.error(`Telegram API error: ${resp.description}`);
    }
  } catch (e) {
    console.error(`Failed to send: ${e.message}`);
  }
}

console.log(`✅ Sent ${successCount}/${chunks.length} message(s) to Telegram`);
