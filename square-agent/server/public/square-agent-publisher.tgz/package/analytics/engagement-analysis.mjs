#!/usr/bin/env node
// SquareAgent - Daily Engagement Analysis
// Runs at 11:00 - Analyzes post performance and generates optimization suggestions
// Replaces OpenClaw cron "币安广场互动分析" (1675e5ec)
//
// Data sources:
//   1. Posts from ~/clawd/data/binance-content/posts/ (local files)
//   2. Creator center stats via Chrome (requires separate scrape step)
//   3. Previous analysis for comparison
//
// Usage:
//   node engagement-analysis.mjs                    # Full analysis
//   node engagement-analysis.mjs --data '{"views":...}'  # With scraped data

import { readFileSync, writeFileSync, existsSync, readdirSync, mkdirSync } from 'fs';
import { join } from 'path';
import { homedir } from 'os';

const DATA_DIR = join(homedir(), 'clawd/data/binance-content');
const POSTS_DIR = join(DATA_DIR, 'posts');
const ANALYTICS_DIR = join(DATA_DIR, 'analytics');
if (!existsSync(ANALYTICS_DIR)) mkdirSync(ANALYTICS_DIR, { recursive: true });

const today = new Date().toISOString().slice(0, 10);
const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);

// Parse CLI --data argument
let scrapedData = null;
const dataIdx = process.argv.indexOf('--data');
if (dataIdx !== -1 && process.argv[dataIdx + 1]) {
  try { scrapedData = JSON.parse(process.argv[dataIdx + 1]); } catch {}
}

// ==========================================
// 1. Collect today's posts
// ==========================================
function getPostsForDate(dateStr) {
  if (!existsSync(POSTS_DIR)) return [];
  return readdirSync(POSTS_DIR)
    .filter(f => f.startsWith(dateStr) && f.endsWith('.md') && !f.includes('engagement-analysis'))
    .map(f => {
      const content = readFileSync(join(POSTS_DIR, f), 'utf8');
      const title = content.split('\n')[0].replace(/^#+\s*/, '').slice(0, 60);
      
      // Extract type from filename
      let type = '其他';
      if (f.includes('vote') || f.includes('投票')) type = '投票';
      else if (f.includes('daily-analysis') || f.includes('深度')) type = '深度分析';
      else if (f.includes('trade-review') || f.includes('复盘')) type = '复盘';
      else if (f.includes('morning') || f.includes('早报')) type = '早报';
      else if (f.includes('hot') || f.includes('热点')) type = '热点';
      else if (f.includes('weekly') || f.includes('周度')) type = '周度总结';
      else if (f.includes('sentiment') || f.includes('情绪')) type = '情绪速报';
      
      // Extract publish time from content if available
      const timeMatch = content.match(/(\d{1,2}:\d{2})/);
      const pubTime = timeMatch ? timeMatch[1] : '未知';
      
      return { file: f, title, type, pubTime, date: dateStr };
    });
}

const todayPosts = getPostsForDate(today);
const yesterdayPosts = getPostsForDate(yesterday);

// ==========================================
// 2. Load scraped data (views/likes/comments)
// ==========================================
let viewsData = {};
if (scrapedData && scrapedData.posts) {
  viewsData = scrapedData.posts;
} else {
  // Try to load from latest scrape file
  const scrapeFile = join(DATA_DIR, 'analytics', `creator-stats-${today}.json`);
  if (existsSync(scrapeFile)) {
    try { viewsData = JSON.parse(readFileSync(scrapeFile, 'utf8')).posts || {}; } catch {}
  }
}

// ==========================================
// 3. Load previous analysis for comparison
// ==========================================
let prevAnalysis = null;
const prevFile = join(POSTS_DIR, `${yesterday}-daily-engagement-analysis.md`);
if (existsSync(prevFile)) {
  const content = readFileSync(prevFile, 'utf8');
  // Extract key metrics
  const followerMatch = content.match(/粉丝[：:]\s*(\d+)/);
  const viewsMatch = content.match(/总浏览量[：:]\s*(\d+)/);
  const postsMatch = content.match(/发帖数[：:]\s*(\d+)/);
  prevAnalysis = {
    followers: followerMatch ? parseInt(followerMatch[1]) : null,
    totalViews: viewsMatch ? parseInt(viewsMatch[1]) : null,
    postCount: postsMatch ? parseInt(postsMatch[1]) : null,
  };
}

// ==========================================
// 4. Load engagement history for trend
// ==========================================
let historyData = [];
for (let i = 1; i <= 7; i++) {
  const d = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10);
  const f = join(POSTS_DIR, `${d}-daily-engagement-analysis.md`);
  if (existsSync(f)) {
    const c = readFileSync(f, 'utf8');
    const views = c.match(/总浏览量[：:]\s*(\d+)/);
    const posts = c.match(/发帖数[：:]\s*(\d+)/);
    const followers = c.match(/粉丝[：:]\s*(\d+)/);
    historyData.push({ date: d, views: views?.[1], posts: posts?.[1], followers: followers?.[1] });
  }
}

// ==========================================
// 5. Count operations for the day
// ==========================================
let commentCount = 0;
const commentLog = join(DATA_DIR, 'comment-log.md');
if (existsSync(commentLog)) {
  const content = readFileSync(commentLog, 'utf8');
  commentCount = (content.match(new RegExp(`\\| ${today}`, 'g')) || []).length;
}

let followCount = 0;
const followLog = join(DATA_DIR, 'follow-log.md');
if (existsSync(followLog)) {
  const content = readFileSync(followLog, 'utf8');
  const section = content.split(`## ${today}`)[1]?.split('## ')[0] || '';
  const totalMatch = section.match(/总计[：:]?\s*(\d+)/);
  followCount = totalMatch ? parseInt(totalMatch[1]) : 0;
}

// ==========================================
// 6. Generate Report
// ==========================================
const dateFormatted = new Date().toLocaleDateString('zh-CN', { month: 'long', day: 'numeric' });

let report = `📊 币安广场每日互动分析｜${dateFormatted}\n\n`;
report += `## 一、数据概览\n\n`;
report += `• 发帖数：${todayPosts.length}篇（${yesterday} 11:00 ~ ${today} 11:00）\n`;
if (scrapedData?.totalViews) report += `• 总浏览量：${scrapedData.totalViews}\n`;
if (scrapedData?.followers) report += `• 粉丝：${scrapedData.followers}${scrapedData.followerChange ? `（${scrapedData.followerChange >= 0 ? '+' : ''}${scrapedData.followerChange}）` : ''}\n`;
if (scrapedData?.totalLikes) report += `• 获赞：${scrapedData.totalLikes}\n`;
report += `• 评论互动：${commentCount} 条\n`;
report += `• 关注涨粉：${followCount} 个\n`;
report += `\n`;

// Post details table
if (todayPosts.length > 0) {
  report += `**帖子明细：**\n\n`;
  report += `| # | 标题 | 时间 | 类型`;
  if (Object.keys(viewsData).length > 0) report += ` | 浏览 | 赞 | 评论`;
  report += ` |\n|---|------|------|------`;
  if (Object.keys(viewsData).length > 0) report += ` | ------ | --- | ------`;
  report += ` |\n`;
  
  todayPosts.forEach((p, i) => {
    report += `| ${i + 1} | ${p.title} | ${p.pubTime} | ${p.type}`;
    if (viewsData[p.file]) {
      report += ` | ${viewsData[p.file].views || '-'} | ${viewsData[p.file].likes || 0} | ${viewsData[p.file].comments || 0}`;
    }
    report += ` |\n`;
  });
  report += `\n`;
}

// Content type comparison
const typeMap = {};
todayPosts.forEach(p => {
  if (!typeMap[p.type]) typeMap[p.type] = { count: 0, views: 0 };
  typeMap[p.type].count++;
  if (viewsData[p.file]?.views) typeMap[p.type].views += viewsData[p.file].views;
});

if (Object.keys(typeMap).length > 0) {
  report += `## 二、内容类型对比\n\n`;
  report += `| 内容类型 | 数量 | 总浏览 | 平均浏览 |\n|---------|------|--------|----------|\n`;
  Object.entries(typeMap).forEach(([type, data]) => {
    const avg = data.count > 0 ? Math.round(data.views / data.count) : 0;
    report += `| ${type} | ${data.count} | ${data.views || '待采集'} | ${avg || '-'} |\n`;
  });
  report += `\n`;
}

// Comparison with yesterday
if (prevAnalysis) {
  report += `## 三、与前日对比\n\n`;
  report += `| 指标 | ${yesterday} | ${today} | 变化 |\n|------|-----------|---------|------|\n`;
  report += `| 发帖数 | ${prevAnalysis.postCount || '-'} | ${todayPosts.length} | ${prevAnalysis.postCount ? (todayPosts.length > prevAnalysis.postCount ? '↑' : '↓') + Math.abs(todayPosts.length - prevAnalysis.postCount) : '-'} |\n`;
  if (scrapedData?.totalViews && prevAnalysis.totalViews) {
    const change = scrapedData.totalViews - prevAnalysis.totalViews;
    const pct = Math.round(change / prevAnalysis.totalViews * 100);
    report += `| 总浏览 | ${prevAnalysis.totalViews} | ${scrapedData.totalViews} | ${change >= 0 ? '↑' : '↓'}${Math.abs(pct)}% |\n`;
  }
  report += `\n`;
}

// Trend data (last 7 days)
if (historyData.length > 0) {
  report += `## 四、7天趋势\n\n`;
  report += `| 日期 | 发帖 | 浏览 | 粉丝 |\n|------|------|------|------|\n`;
  historyData.forEach(h => {
    report += `| ${h.date} | ${h.posts || '-'} | ${h.views || '-'} | ${h.followers || '-'} |\n`;
  });
  report += `\n`;
}

// Operations summary
report += `## 五、今日操作统计\n\n`;
report += `- 发帖：${todayPosts.length} 篇\n`;
report += `- 评论互动：${commentCount} 条\n`;
report += `- 关注涨粉：${followCount} 个\n`;
report += `- **总操作：${todayPosts.length + commentCount + followCount} 次**\n\n`;

// Note about data freshness
if (Object.keys(viewsData).length === 0) {
  report += `> ⚠️ 浏览/互动数据需要从创作者中心采集，请先运行数据采集步骤。\n`;
  report += `> 可手动打开 https://www.binance.com/zh-CN/square/creator-center/home 采集数据后重新运行。\n\n`;
}

report += `---\n*SquareAgent 自动生成 | ${new Date().toISOString()}*\n`;

// Save report
const reportPath = join(POSTS_DIR, `${today}-daily-engagement-analysis.md`);
writeFileSync(reportPath, report);

console.log(`✅ Engagement analysis saved: ${reportPath}`);
console.log(`Posts: ${todayPosts.length} | Comments: ${commentCount} | Follows: ${followCount}`);
if (Object.keys(viewsData).length === 0) {
  console.log(`⚠️ No view data - run creator center scrape first for full analysis`);
}

// Output JSON summary for easy parsing
const summaryFile = join(ANALYTICS_DIR, `engagement-summary-${today}.json`);
writeFileSync(summaryFile, JSON.stringify({
  date: today,
  posts: todayPosts.length,
  comments: commentCount,
  follows: followCount,
  totalOps: todayPosts.length + commentCount + followCount,
  viewsData: scrapedData || null,
  previousAnalysis: prevAnalysis,
  postTypes: typeMap,
  generatedAt: new Date().toISOString(),
}, null, 2));
console.log(`Summary JSON: ${summaryFile}`);
