#!/usr/bin/env node
// SquareAgent - Morning Hot Topics Report
// Runs at 07:30 - Collects market data and hot topics from CoinGecko/CoinMarketCap
// Replaces OpenClaw cron "早间热点分析" (8da351ab)

import { execSync } from 'child_process';
import { writeFileSync, existsSync, mkdirSync } from 'fs';
import { join } from 'path';
import { homedir } from 'os';

const PROXY = 'http://127.0.0.1:7890';
const CURL = `curl --silent --max-time 15 -x ${PROXY}`;
const DATA_DIR = join(homedir(), 'clawd/data/binance-content/analytics');
const today = new Date().toISOString().slice(0, 10);

if (!existsSync(DATA_DIR)) mkdirSync(DATA_DIR, { recursive: true });

function curl(url) {
  try {
    return execSync(`${CURL} "${url}"`, { encoding: 'utf8', timeout: 20000 });
  } catch (e) {
    return null;
  }
}

// 1. BTC/ETH market data
let marketData = {};
try {
  const [btcRaw, ethRaw] = [
    curl('https://api.binance.com/api/v3/ticker/24hr?symbol=BTCUSDT'),
    curl('https://api.binance.com/api/v3/ticker/24hr?symbol=ETHUSDT'),
  ];
  if (btcRaw) {
    const btc = JSON.parse(btcRaw);
    marketData.btcPrice = parseFloat(btc.lastPrice);
    marketData.btcChange = parseFloat(btc.priceChangePercent);
    marketData.btcHigh = parseFloat(btc.highPrice);
    marketData.btcLow = parseFloat(btc.lowPrice);
  }
  if (ethRaw) {
    const eth = JSON.parse(ethRaw);
    marketData.ethPrice = parseFloat(eth.lastPrice);
    marketData.ethChange = parseFloat(eth.priceChangePercent);
  }
} catch {}

// 2. Fear & Greed Index
let fearGreed = {};
try {
  const fgRaw = curl('https://api.alternative.me/fng/?limit=1');
  if (fgRaw) {
    const fgData = JSON.parse(fgRaw);
    fearGreed = {
      value: parseInt(fgData.data[0].value),
      label: fgData.data[0].value_classification,
    };
  }
} catch {}

// 3. CoinGecko trending
let trending = [];
try {
  const cgRaw = curl('https://api.coingecko.com/api/v3/search/trending');
  if (cgRaw) {
    const cgData = JSON.parse(cgRaw);
    trending = (cgData.coins || []).slice(0, 5).map(c => ({
      name: c.item.name,
      symbol: c.item.symbol,
      marketCapRank: c.item.market_cap_rank,
      priceBtc: c.item.price_btc?.toString().slice(0, 10),
    }));
  }
} catch {}

// 4. Build report
const fmt = n => '$' + n.toLocaleString('en-US', { maximumFractionDigits: 0 });
const dateStr = new Date().toLocaleDateString('zh-CN', { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' });

let report = `# 📰 每日加密市场热点报告\n**日期：${dateStr}**\n\n---\n\n## 📊 市场概况\n\n`;
report += `| 指标 | 数值 | 变化 |\n|------|------|------|\n`;
if (marketData.btcPrice) {
  const dir = marketData.btcChange >= 0 ? '+' : '';
  report += `| BTC | ${fmt(marketData.btcPrice)} | 24h ${dir}${marketData.btcChange.toFixed(2)}% |\n`;
}
if (marketData.ethPrice) {
  const dir = marketData.ethChange >= 0 ? '+' : '';
  report += `| ETH | ${fmt(marketData.ethPrice)} | 24h ${dir}${marketData.ethChange.toFixed(2)}% |\n`;
}
if (fearGreed.value) {
  report += `| **恐惧贪婪指数** | **${fearGreed.value}** | **${fearGreed.label}** |\n`;
}
report += `\n`;

if (trending.length > 0) {
  report += `## 🔥 CoinGecko 热门币种\n\n`;
  trending.forEach((c, i) => {
    report += `${i + 1}. **${c.name}** (${c.symbol}) - 市值排名 #${c.marketCapRank || 'N/A'}\n`;
  });
  report += `\n`;
}

report += `---\n*自动生成 by SquareAgent | ${new Date().toISOString()}*\n`;

// Save report
const reportPath = join(DATA_DIR, `daily-hot-topics-${today}.md`);
writeFileSync(reportPath, report);

console.log(`✅ Hot topics report saved: ${reportPath}`);
console.log(`BTC ${marketData.btcPrice ? fmt(marketData.btcPrice) : 'N/A'} | Fear: ${fearGreed.value || 'N/A'}/100 | Trending: ${trending.length} coins`);
