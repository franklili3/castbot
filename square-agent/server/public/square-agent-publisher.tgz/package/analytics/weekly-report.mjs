#!/usr/bin/env node
// SquareAgent - Weekly Interaction Report
// Runs Sunday 22:00 - Weekly summary of engagement, followers, content performance
// Replaces OpenClaw cron "周度互动分析" (6ee37c8d)

import { readFileSync, readdirSync, existsSync, writeFileSync, mkdirSync } from 'fs';
import { join } from 'path';
import { homedir } from 'os';

const DATA_DIR = join(homedir(), 'clawd/data/binance-content');
const ANALYTICS_DIR = join(DATA_DIR, 'analytics');
if (!existsSync(ANALYTICS_DIR)) mkdirSync(ANALYTICS_DIR, { recursive: true });

// Get this week's date range (Mon-Sun)
const now = new Date();
const dayOfWeek = now.getDay(); // 0=Sun
const mondayOffset = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;
const monday = new Date(now);
monday.setDate(now.getDate() + mondayOffset);
const sunday = new Date(monday);
sunday.setDate(monday.getDate() + 6);

function formatDate(d) { return d.toISOString().slice(0, 10); }
const weekStart = formatDate(monday);
const weekEnd = formatDate(sunday);
const weekLabel = `${weekStart} ~ ${weekEnd}`;

// Collect data for each day this week
let totalComments = 0;
let totalFollows = 0;
let totalPosts = 0;
const dailyData = [];

for (let d = new Date(monday); d <= sunday; d.setDate(d.getDate() + 1)) {
  const dateStr = formatDate(d);
  
  // Count comments
  let comments = 0;
  const commentLog = join(DATA_DIR, 'comment-log.md');
  if (existsSync(commentLog)) {
    const content = readFileSync(commentLog, 'utf8');
    const matches = content.match(new RegExp(`\\| ${dateStr}`, 'g'));
    comments = matches ? matches.length : 0;
  }
  
  // Count follows - check follow log
  let follows = 0;
  const followLog = join(DATA_DIR, 'follow-log.md');
  if (existsSync(followLog)) {
    const content = readFileSync(followLog, 'utf8');
    const section = content.split(`## ${dateStr}`)[1]?.split('## ')[0] || '';
    const totalMatch = section.match(/总计[：:]?\s*(\d+)/);
    follows = totalMatch ? parseInt(totalMatch[1]) : 0;
  }
  
  // Count posts
  let posts = 0;
  const postsDir = join(DATA_DIR, 'posts');
  if (existsSync(postsDir)) {
    posts = readdirSync(postsDir).filter(f => f.startsWith(dateStr) && f.endsWith('.md')).length;
  }
  
  totalComments += comments;
  totalFollows += follows;
  totalPosts += posts;
  
  dailyData.push({ date: dateStr, posts, comments, follows, total: posts + comments + follows });
}

const totalOps = totalPosts + totalComments + totalFollows;

// Find top content
const postsDir = join(DATA_DIR, 'posts');
let topContent = [];
if (existsSync(postsDir)) {
  for (let d = new Date(monday); d <= sunday; d.setDate(d.getDate() + 1)) {
    const dateStr = formatDate(d);
    const files = readdirSync(postsDir).filter(f => f.startsWith(dateStr) && f.endsWith('.md'));
    for (const f of files) {
      const content = readFileSync(join(postsDir, f), 'utf8');
      const title = content.split('\n')[0].replace(/^#+\s*/, '');
      topContent.push({ date: dateStr, file: f, title: title.slice(0, 60) });
    }
  }
}

// Build report
const weekNum = Math.ceil((now - new Date(now.getFullYear(), 0, 1)) / (7 * 24 * 60 * 60 * 1000));
let report = `# 📊 周度互动分析报告 | 第${weekNum}周\n**${weekLabel}**\n\n---\n\n`;
report += `## 📈 本周汇总\n\n`;
report += `| 指标 | 数量 |\n|------|------|\n`;
report += `| 发帖 | ${totalPosts} 篇 |\n`;
report += `| 评论互动 | ${totalComments} 条 |\n`;
report += `| 关注涨粉 | ${totalFollows} 个 |\n`;
report += `| **总操作** | **${totalOps} 次** |\n\n`;

report += `## 📅 每日明细\n\n`;
report += `| 日期 | 发帖 | 评论 | 关注 | 合计 |\n|------|------|------|------|------|\n`;
dailyData.forEach(d => {
  report += `| ${d.date} | ${d.posts} | ${d.comments} | ${d.follows} | ${d.total} |\n`;
});
report += `\n`;

if (topContent.length > 0) {
  report += `## 📝 本周内容\n\n`;
  topContent.forEach(c => {
    report += `- **${c.date}**: ${c.title}\n`;
  });
  report += `\n`;
}

report += `---\n*自动生成 by SquareAgent | ${new Date().toISOString()}*\n`;

// Save
const reportPath = join(ANALYTICS_DIR, `weekly-interaction-${weekNum}.md`);
writeFileSync(reportPath, report);

console.log(`✅ Weekly report saved: ${reportPath}`);
console.log(`Week ${weekNum}: ${totalPosts} posts, ${totalComments} comments, ${totalFollows} follows = ${totalOps} total ops`);
