#!/usr/bin/env node
// SquareAgent - Daily Operations Stats
// Runs at 23:00 - Counts today's operations from log files
// Replaces OpenClaw cron "每日操作统计汇总" (149e8b85)

import { readFileSync, writeFileSync, existsSync, appendFileSync, readdirSync } from 'fs';
import { join } from 'path';
import { homedir } from 'os';

const DATA_DIR = join(homedir(), 'clawd/data/binance-content');
const today = new Date().toISOString().slice(0, 10);

function countTodayEntries(filePath, datePattern) {
  if (!existsSync(filePath)) return 0;
  const content = readFileSync(filePath, 'utf8');
  const regex = new RegExp(datePattern || today, 'g');
  return (content.match(regex) || []).length;
}

// Count posts
const postsDir = join(DATA_DIR, 'posts');
const postCount = existsSync(postsDir)
  ? readdirSync(postsDir).filter(f => f.startsWith(today) && f.endsWith('.md')).length
  : 0;

// Count comments
const commentLog = join(DATA_DIR, 'comment-log.md');
const commentCount = countTodayEntries(commentLog, `\\| ${today}`);

// Count follows
const followLog = join(DATA_DIR, 'follow-log.md');
let followCount = 0;
if (existsSync(followLog)) {
  const content = readFileSync(followLog, 'utf8');
  // Look for today's section and count "个" or numbers
  const todaySection = content.split(`## ${today}`)[1]?.split('## ')[0] || '';
  const totalMatch = todaySection.match(/总计[：:]?\s*(\d+)/);
  followCount = totalMatch ? parseInt(totalMatch[1]) : 0;
}

// Count posts (already done above)

const totalOps = commentCount + followCount + postCount;

// Append to operations log
const opsLog = join(DATA_DIR, 'operations-log.md');
const summary = `
### ${today} 统计
- **发帖**: ${postCount} 篇
- **评论互动**: ${commentCount} 条
- **关注涨粉**: ${followCount} 个
- **今日总计**: ${totalOps} 次操作

`;

if (existsSync(opsLog)) {
  appendFileSync(opsLog, summary);
} else {
  writeFileSync(opsLog, `# 币安广场运营统计\n${summary}`);
}

// Output for cron notification
const output = `📊 ${today} 运营统计\n发帖: ${postCount} | 评论: ${commentCount} | 关注: ${followCount}\n今日总计: ${totalOps} 次操作`;

console.log(output);

// Write to a status file for easy reading
const statusFile = join(homedir(), '.square-agent-publisher/logs/daily-stats.json');
writeFileSync(statusFile, JSON.stringify({
  date: today,
  posts: postCount,
  comments: commentCount,
  follows: followCount,
  total: totalOps,
  generatedAt: new Date().toISOString(),
}, null, 2));
