/**
 * 操作码引擎 v2
 * 
 * 云端下发操作码序列，Agent本地解码执行
 * 配置参数只在内存中使用，不写入磁盘
 */

import { execSync } from 'child_process';
import fs from 'fs';
import { OPCODES, JS_TEMPLATES, CHROME_OFFSET, decodeOps } from './opcodes.mjs';
import { humanDelay, jitterCoords, bezierPath, checkQuietHours } from './humanize.mjs';

// ========== 底层工具 ==========

function run(cmd) {
  try {
    return { ok: true, data: execSync(cmd, { timeout: 15000 }).toString().trim() };
  } catch (e) {
    return { ok: false, error: (e.stderr || e).toString().substring(0, 300) };
  }
}

function js(code) {
  const f = `/tmp/ba-${Date.now()}.js`;
  fs.writeFileSync(f, code);
  // 始终用 window 1（pk 会先把目标窗口激活到 index 1）
  return run(`osascript -e 'tell application "Google Chrome" to tell active tab of window 1 to return execute javascript (do shell script "cat ${f}")'`);
}

function pk(action, args = '') {
  // 先激活 agent 专属窗口到 index 1，确保后续所有操作都发到正确窗口
  const winIdx = process.env.AGENT_WINDOW_INDEX || 1;
  if (winIdx !== 1) {
    try { run(`osascript -e 'tell application "Google Chrome" to set index of window ${winIdx} to 1'`); } catch {}
  }
  return run(`peekaboo ${action} ${args}`.trim());
}

const sleep = ms => new Promise(r => setTimeout(r, ms));

// 拟人化延迟
const humanSleep = (baseMs) => sleep(humanDelay(baseMs));

function viewportToGlobal(viewportY) {
  return CHROME_OFFSET.screen_y + CHROME_OFFSET.ui_height + viewportY;
}

// ========== JS模板渲染（用参数替换占位符） ==========

function renderJS(templateId, params) {
  let code = JS_TEMPLATES[templateId];
  if (!code) return null;
  
  // 替换参数占位符
  if (templateId === 'click_vote') {
    code = code.replace('PLACEHOLDER', params.text || '创建投票')
               .replace('YMIN', params.y_min || 400)
               .replace('YMAX', params.y_max || 700);
  } else if (templateId === 'find_inputs') {
    code = code.replace('YMIN', params.y_min || 400)
               .replace('YMAX', params.y_max || 530)
               .replace('MINW', params.min_w || 100);
  } else if (templateId === 'find_btn') {
    code = code.replace('PLACEHOLDER', params.text || '发文')
               .replace('XMIN', params.x_min || 800)
               .replace('XMAX', params.x_max || 950)
               .replace('WMIN', params.w_min || 50)
               .replace('WMAX', params.w_max || 100);
  }
  
  return code;
}

// ========== 操作执行器 ==========

async function executeOp(op, params, taskData) {
  switch (op) {
    // 基础操作
    case 'navigate':
      run(`osascript -e 'tell application "Google Chrome" to tell window 1 to set URL of active tab to "${params[0]}"'`);
      return { ok: true, data: 'navigated' };

    case 'click_coords': {
      const j1 = jitterCoords(params[0], params[1], 3);
      return pk('click', `--coords ${j1.x},${j1.y} --app "Google Chrome"`);
    }

    case 'click_global': {
      const j2 = jitterCoords(params[0], params[1], 3);
      return pk('click', `--global-coords --coords ${j2.x},${j2.y} --app "Google Chrome"`);
    }

    case 'paste_text':
      const text = (taskData.content || params[0] || '').replace(/\\/g, '\\\\').replace(/"/g, '\\"');
      return pk('paste', `--text "${text}" --app "Google Chrome"`);

    case 'type_text':
      return pk('type', `"${params[0]}" --app "Google Chrome"`);

    case 'press_key':
      return pk('press', `${params[0]} --app "Google Chrome"`);

    case 'run_js':
      const code = renderJS(params[0], params[1] || {});
      if (!code) return { ok: false, error: `js_template_not_found: ${params[0]}` };
      return js(code);

    case 'sleep':
      await sleep(params[0] || 1000);
      return { ok: true, data: `slept ${params[0]}ms` };

    // 复合操作
    case 'expand_editor':
      pk('click', `--coords ${params[0] || 500},${params[1] || 170} --app "Google Chrome"`);
      return { ok: true, data: 'clicked_editor' };

    case 'focus_editor':
      return js(JS_TEMPLATES.focus_pm);

    case 'input_content':
      const escaped = (taskData.content || '').replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/`/g, '\\`');
      return pk('paste', `--text "${escaped}" --app "Google Chrome"`);

    case 'scroll_top':
      return js(JS_TEMPLATES.scroll_top);

    case 'add_topics':
      if (taskData.topics?.length > 0) {
        for (const topic of taskData.topics) {
          pk('type', `"#${topic}" --app "Google Chrome"`);
          await sleep(params[0] || 2000);
          pk('press', 'enter --app "Google Chrome"');
          await sleep(params[1] || 500);
        }
      }
      return { ok: true, data: taskData.topics?.join(',') || 'none' };

    // 投票操作
    case 'open_more_menu':
      return pk('click', `--global-coords --coords ${params[0]},${params[1]} --app "Google Chrome"`);

    case 'create_poll': {
      const code = renderJS('click_vote', {
        text: params[0] || '创建投票',
        y_min: params[1] || 400,
        y_max: params[2] || 700
      });
      return js(code);
    }

    case 'fill_poll_option': {
      const optIndex = params[0] || 0;
      const baseY = params[1] || 429;
      const stepY = params[2] || 52;
      const vx = params[3] || 480;
      const vy = baseY + optIndex * stepY;
      const gy = viewportToGlobal(vy);
      
      // 点击选项input
      pk('click', `--global-coords --coords ${vx},${gy} --app "Google Chrome"`);
      await sleep(500);
      
      // 检查焦点
      const focusR = js(JS_TEMPLATES.check_focus);
      const optionText = taskData.options?.[optIndex] || '';
      
      if (focusR.data?.includes('选项')) {
        return pk('type', `"${optionText}" --app "Google Chrome"`);
      }
      return { ok: false, data: `focus_wrong: ${focusR.data}` };
    }

    case 'verify_poll_inputs': {
      const code = renderJS('find_inputs', {
        y_min: params[0] || 400,
        y_max: params[1] || 530,
        min_w: params[2] || 100
      });
      return js(code);
    }

    // 发布操作
    case 'find_publish_btn': {
      const code = renderJS('find_btn', {
        text: params[0] || '发文',
        x_min: params[1] || 800,
        x_max: params[2] || 950,
        w_min: params[3] || 50,
        w_max: params[4] || 100
      });
      const r = js(code);
      // 解析y坐标，存到taskData供click_publish使用
      const yMatch = (r.data || '').match(/y=(\d+)/);
      if (yMatch) taskData._btnViewportY = parseInt(yMatch[1]);
      return r;
    }

    case 'click_publish': {
      const bvy = taskData._btnViewportY;
      if (!bvy) return { ok: false, data: 'no_btn_y' };
      const offsetX = params[0] || 903;
      const offsetY = params[1] || 16;
      const gy = viewportToGlobal(bvy + offsetY);
      return pk('click', `--global-coords --coords ${offsetX},${gy} --app "Google Chrome"`);
    }

    // 检查操作
    case 'check_focus':
      return js(JS_TEMPLATES.check_focus);

    case 'verify_content':
      return js(JS_TEMPLATES.check_pm);

    case 'check_pm_exists':
      return js('(function(){var pm=document.querySelector(".ProseMirror");return pm?"exists":"no_pm";})()');

    // 评论操作
    case 'find_comment_box':
      return js(JS_TEMPLATES.find_comment);

    case 'submit_comment':
      return js(JS_TEMPLATES.submit);

    default:
      return { ok: false, error: `unknown_op: ${op}` };
  }
}

// ========== 主入口：执行ops序列 ==========

/**
 * 执行云端下发的操作码序列
 * @param {Object} task - { id, type, ops: [{k,p,d},...], content, topics, options }
 * @returns {Object} { success, steps, duration_ms }
 */
export async function executeTask(task) {
  const log = [];
  const t0 = Date.now();
  const taskData = {
    content: task.content,
    topics: task.topics,
    options: task.options,
    post_url: task.post_url,
    comment: task.comment,
    _btnViewportY: null  // 内部状态
  };

  if (!task.ops || !task.ops.length) {
    return { success: false, error: 'no_ops', steps: log };
  }

  const steps = decodeOps(task.ops);

  for (let i = 0; i < steps.length; i++) {
    const step = steps[i];
    try {
      const r = await executeOp(step.op, step.params, taskData);
      log.push({ step: step.op, ok: r.ok, detail: (r.data || r.error || '').substring(0, 80) });
      
      // 关键失败检查
      if (!r.ok && ['focus_editor', 'input_content', 'click_publish'].includes(step.op)) {
        // 不立即失败，继续尝试后续步骤
      }
    } catch (e) {
      log.push({ step: step.op, ok: false, detail: e.message.substring(0, 80) });
    }

    // 延迟（拟人化）
    if (step.delay > 0) {
      await humanSleep(step.delay);
    }
  }

  // 关键步骤失败时的诊断信息
  const failures = log.filter(s => !s.ok);

  // 如果关键步骤全部失败，标记整体失败
  const criticalOps = ['input_content', 'click_publish', 'paste_text'];
  const criticalFailures = failures.filter(s => criticalOps.includes(s.step));
  
  // 只要有任何关键步骤成功或所有步骤完成，就算成功（部分失败会在steps中体现）
  // 只有当完全没有输出内容时才算失败
  const hasContent = log.some(s => s.step === 'input_content' && s.ok);
  const hasPublished = log.some(s => s.step === 'click_publish' && s.ok);
  
  const success = hasContent && hasPublished;

  return { success, steps: log, duration_ms: Date.now() - t0, failures: criticalFailures.length };
}

// ========== 便捷方法：手动模式（兼容旧API） ==========

export { executeTask as publishPost };
export { executeTask as publishPoll };
export { executeTask as publishComment };

export async function getStats(range = '7days') {
  const map = { yesterday: '昨日', '7days': '近7天', '30days': '近30天', all: '全部' };
  const target = map[range] || '近7天';

  run(`osascript -e 'tell application "Google Chrome" to tell window 1 to set URL of active tab to "https://www.binance.com/zh-CN/square/creator-center/home"'`);
  await sleep(5000);

  js(`(function(){var a=document.querySelectorAll('div');for(var i=0;i<a.length;i++){if((a[i].textContent||'').trim()==='${target}'&&a[i].getBoundingClientRect().width>50&&a[i].getBoundingClientRect().y>250){a[i].click();return 'clicked';}}return 'not_found';})()`);
  await sleep(2000);

  const r = js(`(function(){var a=document.querySelectorAll('*');var result=[];for(var i=0;i<a.length;i++){var rect=a[i].getBoundingClientRect();if(rect.y>280&&rect.y<420&&rect.x>300&&rect.x<1100&&rect.width>30&&a[i].children.length===0){var t=(a[i].textContent||'').trim();if(t.length>0&&t.length<50)result.push(t);}}return result.join('|');})()`);

  return { success: true, range, data: r.data };
}
