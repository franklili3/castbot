/**
 * 拟人化模块 - 让自动化操作更像真人
 * 
 * 核心改进：
 * 1. 鼠标移动轨迹（Bézier曲线，不是瞬移）
 * 2. 随机点击偏移（±3像素）
 * 3. 随机延迟抖动（±30%）
 * 4. 打字速度波动（100-180 WPM）
 * 5. 偶尔的"犹豫"（鼠标移过去停顿再点）
 * 6. 夜间静默（23:00-08:00不操作）
 */

// ========== 随机工具 ==========

/** 区间随机数 */
function rand(min, max) {
  return min + Math.random() * (max - min);
}

/** 随机整数 */
function randInt(min, max) {
  return Math.floor(rand(min, max + 1));
}

/** 正态分布随机（Box-Muller） */
function gaussRand(mean = 0, stddev = 1) {
  const u = 1 - Math.random();
  const v = Math.random();
  const z = Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  return z * stddev + mean;
}

// ========== 时间控制 ==========

/**
 * 判断是否在静默时段
 * @param {string} timezone - IANA timezone
 * @returns {{ quiet: boolean, reason?: string }}
 */
export function checkQuietHours(timezone = 'Asia/Shanghai') {
  const now = new Date();
  const hour = parseInt(now.toLocaleString('en-US', { hour: 'numeric', hour12: false, timeZone: timezone }));
  
  // 23:00 - 08:00 静默
  if (hour >= 23 || hour < 8) {
    return { quiet: true, reason: `静默时段(${hour}:00)，跳过操作` };
  }
  return { quiet: false };
}

/**
 * 带抖动的延迟
 * 基础延迟 ± 30% 随机波动，加上偶尔的"犹豫"
 * @param {number} baseMs - 基础延迟（ms）
 * @returns {number} 实际延迟
 */
export function humanDelay(baseMs) {
  // 基础抖动：±30%
  let jitter = baseMs * rand(-0.3, 0.3);
  
  // 10%概率"犹豫"（额外1-3秒停顿）
  if (Math.random() < 0.1) {
    jitter += rand(1000, 3000);
  }
  
  return Math.max(100, Math.round(baseMs + jitter));
}

/**
 * 批量操作的间隔（模拟人类做一系列操作的节奏）
 * @param {number} index - 当前操作序号
 * @param {number} total - 总操作数
 * @returns {number} 间隔ms
 */
export function batchInterval(index, total) {
  // 基础间隔 3-8秒
  let base = rand(3000, 8000);
  
  // 开头慢（还在"浏览"）
  if (index < 3) base *= 1.5;
  
  // 中间加速（进入节奏）
  if (index > 3 && index < total - 3) base *= 0.8;
  
  // 快结束时又变慢（疲劳/更仔细）
  if (index >= total - 3) base *= 1.3;
  
  // 5%概率长停顿（分心了/看别的去了）
  if (Math.random() < 0.05) base += rand(15000, 45000);
  
  return Math.round(base);
}

// ========== 鼠标轨迹 ==========

/**
 * 生成Bézier曲线路径（从当前位置到目标位置）
 * @param {number} x1 - 起点x
 * @param {param} y1 - 起点y  
 * @param {number} x2 - 终点x
 * @param {number} y2 - 终点y
 * @param {number} steps - 路径点数（越多越平滑）
 * @returns {Array<{x, y}>} 路径点数组
 */
export function bezierPath(x1, y1, x2, y2, steps = 20) {
  // 随机控制点（让轨迹不直线）
  const cx1 = x1 + (x2 - x1) * rand(0.2, 0.5) + gaussRand(0, 30);
  const cy1 = y1 + (y2 - y1) * rand(0.2, 0.5) + gaussRand(0, 30);
  const cx2 = x1 + (x2 - x1) * rand(0.5, 0.8) + gaussRand(0, 30);
  const cy2 = y1 + (y2 - y1) * rand(0.5, 0.8) + gaussRand(0, 30);
  
  const path = [];
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const x = Math.pow(1-t,3)*x1 + 3*Math.pow(1-t,2)*t*cx1 + 3*(1-t)*t*t*cx2 + t*t*t*x2;
    const y = Math.pow(1-t,3)*y1 + 3*Math.pow(1-t,2)*t*cy1 + 3*(1-t)*t*t*cy2 + t*t*t*y2;
    path.push({ x: Math.round(x), y: Math.round(y) });
  }
  return path;
}

/**
 * 随机偏移点击位置（人类不会点得那么准）
 * @param {number} x - 目标x
 * @param {number} y - 目标y
 * @param {number} maxOffset - 最大偏移像素
 * @returns {{x, y}} 偏移后的坐标
 */
export function jitterCoords(x, y, maxOffset = 3) {
  // 正态分布偏移（更集中在中心）
  return {
    x: Math.round(x + gaussRand(0, maxOffset * 0.5)),
    y: Math.round(y + gaussRand(0, maxOffset * 0.5))
  };
}

// ========== 打字模拟 ==========

/**
 * 模拟人类打字节奏（每字符间隔）
 * @param {string} text - 要打的文本
 * @returns {Array<number>} 每个字符的间隔时间（ms）
 */
export function typingRhythm(text) {
  const intervals = [];
  const baseCpm = rand(300, 600); // 每分钟字符数（100-180 WPM ≈ 300-600 CPM）
  const baseInterval = 60000 / baseCpm;
  
  for (let i = 0; i < text.length; i++) {
    let delay = baseInterval;
    
    // 标点后面停顿长一点
    if (i > 0 && '，。！？、；：'.includes(text[i-1])) {
      delay *= rand(2, 4);
    }
    // 换行前停顿
    if (text[i] === '\n') {
      delay *= rand(3, 6);
    }
    // 空格前略微加速
    if (text[i] === ' ') {
      delay *= 0.7;
    }
    // 随机抖动
    delay *= rand(0.6, 1.4);
    
    intervals.push(Math.max(20, Math.round(delay)));
  }
  
  return intervals;
}

// ========== 操作节奏 ==========

/**
 * 计算一整套操作的发布时机
 * 避免固定时间发布，模拟人类的随意性
 * @param {Object} schedule - 原始排期 { hour, minute }
 * @returns {{ hour, minute, reason }} 实际发布时间
 */
export function humanizeSchedule(schedule) {
  let { hour, minute } = schedule;
  
  // ±15分钟随机偏移
  minute += randInt(-15, 15);
  if (minute < 0) { minute += 60; hour -= 1; }
  if (minute >= 60) { minute -= 60; hour += 1; }
  
  // 10%概率推迟1-2小时（"忘了"/"忙别的"）
  if (Math.random() < 0.1) {
    hour += randInt(1, 2);
  }
  
  return { hour: hour % 24, minute };
}

/**
 * 评论操作的节奏控制
 * 每条评论之间要有合理的间隔
 * @param {number} index - 当前评论序号
 * @param {number} total - 总评论数
 * @returns {number} 下一条评论前的等待时间（ms）
 */
export function commentPace(index, total) {
  // 基础间隔：30-90秒
  let delay = rand(30000, 90000);
  
  // 每做5-8条，休息2-5分钟（"看了一会儿再继续"）
  if (index > 0 && index % randInt(5, 8) === 0) {
    delay += rand(120000, 300000);
  }
  
  // 偶尔长休息（去做别的事了）
  if (Math.random() < 0.08) {
    delay += rand(300000, 600000); // 5-10分钟
  }
  
  return Math.round(delay);
}

/**
 * 生成操作之间的"微行为"（随机浏览/滚动/停顿）
 * 让操作序列不像机器人那么规律
 * @returns {Array} 微操作序列（可插入到主操作之间）
 */
export function microBehaviors() {
  const behaviors = [];
  
  // 30%概率：随机滚动一下
  if (Math.random() < 0.3) {
    const scrollY = randInt(100, 500);
    behaviors.push({ type: 'scroll', y: scrollY, delay: rand(500, 1500) });
  }
  
  // 15%概率：鼠标移动到无关位置（"看了看别的"）
  if (Math.random() < 0.15) {
    behaviors.push({ type: 'move_mouse', x: randInt(200, 1200), y: randInt(200, 700), delay: rand(1000, 3000) });
  }
  
  return behaviors;
}

// ========== 发布频率限制 ==========

const DAILY_LIMITS = {
  max_posts: 8,          // 每天最多8条帖子
  max_comments: 50,      // 每天最多50条评论
  min_post_interval: 30 * 60 * 1000, // 帖子间隔最少30分钟
  max_posts_per_hour: 2, // 每小时最多2条
};

/**
 * 检查是否可以发布（频率限制）
 * @param {Array} todayPosts - 今天的发帖时间戳列表
 * @returns {{ allowed: boolean, reason?: string, waitMs?: number }}
 */
export function checkPublishLimit(todayPosts = []) {
  const now = Date.now();
  const oneHourAgo = now - 3600000;
  const oneDayAgo = now - 86400000;
  
  // 日总量限制
  const todayCount = todayPosts.filter(t => t > oneDayAgo).length;
  if (todayCount >= DAILY_LIMITS.max_posts) {
    return { allowed: false, reason: `今天已发${todayCount}条，达到日上限${DAILY_LIMITS.max_posts}` };
  }
  
  // 每小时限制
  const hourCount = todayPosts.filter(t => t > oneHourAgo).length;
  if (hourCount >= DAILY_LIMITS.max_posts_per_hour) {
    return { allowed: false, reason: `过去1小时已发${hourCount}条，限制${DAILY_LIMITS.max_posts_per_hour}/小时` };
  }
  
  // 最小间隔
  const lastPost = todayPosts[todayPosts.length - 1];
  if (lastPost && (now - lastPost) < DAILY_LIMITS.min_post_interval) {
    const waitMs = DAILY_LIMITS.min_post_interval - (now - lastPost);
    return { allowed: false, reason: `距上次发帖不到30分钟，需等${Math.round(waitMs/60000)}分钟`, waitMs };
  }
  
  return { allowed: true };
}

export { DAILY_LIMITS };
