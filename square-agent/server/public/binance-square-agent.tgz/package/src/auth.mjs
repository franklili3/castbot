/**
 * 认证模块
 * - 保存 API Key 到本地配置
 * - 验证 API Key 有效性
 */

import fs from 'fs';
import path from 'path';
import os from 'os';
import https from 'https';
import http from 'http';

const CONFIG_DIR = path.join(os.homedir(), '.binance-agent');
const CONFIG_FILE = path.join(CONFIG_DIR, 'config.json');

export function getConfig() {
  try {
    return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
  } catch {
    return null;
  }
}

export function saveConfig(config) {
  if (!fs.existsSync(CONFIG_DIR)) fs.mkdirSync(CONFIG_DIR, { recursive: true });
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
}

export async function login(apiKey) {
  console.log('🔐 Verifying API key...');
  
  // 验证 API Key 格式
  if (!apiKey.startsWith('sk-') && !apiKey.startsWith('bsq_')) {
    console.error('❌ Invalid API key format. Should start with sk- or bsq_');
    process.exit(1);
  }

  // 调云端API验证
  const result = await httpGet(`/api/agent/verify?key=${apiKey}`);
  
  if (!result.ok) {
    console.error('❌ API key verification failed:', result.error);
    console.error('   Please check your key and try again.');
    process.exit(1);
  }

  const data = JSON.parse(result.data);
  
  // 保存配置
  saveConfig({
    apiKey,
    userId: data.user_id,
    plan: data.plan,
    serverUrl: data.server_url || 'http://127.0.0.1:5577',
    loggedInAt: new Date().toISOString()
  });

  console.log('✅ Login successful!');
  console.log(`   User: ${data.user_id}`);
  console.log(`   Plan: ${data.plan}`);
  console.log(`   Server: ${data.server_url || 'http://127.0.0.1:5577'}`);
  console.log('');
  console.log('Run `binance-agent start` to begin.');
}

// 简易 HTTP 请求
function httpGet(path, serverUrl) {
  const config = getConfig();
  const baseUrl = (serverUrl || config?.serverUrl || 'http://127.0.0.1:5577').replace(/\/$/, '');
  const isLocal = baseUrl.startsWith('http://');
  const requester = isLocal ? http : https;
  
  return new Promise((resolve) => {
    const url = new URL(path, baseUrl);
    const headers = { timeout: 10000 };
    if (config?.apiKey) headers.headers = { 'Authorization': `Bearer ${config.apiKey}` };
    const req = requester.get(url, headers, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        if (res.statusCode === 200) {
          resolve({ ok: true, data });
        } else {
          resolve({ ok: false, error: `HTTP ${res.statusCode}: ${data}` });
        }
      });
    });
    req.on('error', (e) => resolve({ ok: false, error: e.message }));
    req.on('timeout', () => { req.destroy(); resolve({ ok: false, error: 'timeout' }); });
  });
}

export { httpGet };

// HTTP POST
export function httpPost(path, body) {
  const config = getConfig();
  const baseUrl = (config?.serverUrl || 'http://127.0.0.1:5577').replace(/\/$/, '');
  const isLocal = baseUrl.startsWith('http://');
  const requester = isLocal ? http : https;
  
  return new Promise((resolve) => {
    const url = new URL(path, baseUrl);
    const postData = JSON.stringify(body);
    
    const req = requester.request(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${config?.apiKey || ''}`,
        'Content-Length': Buffer.byteLength(postData)
      },
      timeout: 15000
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        if (res.statusCode >= 200 && res.statusCode < 300) {
          resolve({ ok: true, data });
        } else {
          resolve({ ok: false, error: `HTTP ${res.statusCode}: ${data}` });
        }
      });
    });
    req.on('error', (e) => resolve({ ok: false, error: e.message }));
    req.on('timeout', () => { req.destroy(); resolve({ ok: false, error: 'timeout' }); });
    req.write(postData);
    req.end();
  });
}
