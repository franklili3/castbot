/**
 * Agent 主模块
 * - 轮询云端API拉取任务
 * - 调用 publisher 执行
 * - 上报结果
 */

import { getConfig, httpGet, httpPost } from './auth.mjs';
import { publishPost, publishPoll, publishComment, getStats } from './publisher.mjs';
import { execSync, spawn } from 'child_process';
import fs from 'fs';
import path from 'path';
import os from 'os';

const LOG_DIR = path.join(os.homedir(), '.binance-agent', 'logs');
const POLL_INTERVAL = 30_000; // 30秒轮询
const PID_FILE = path.join(os.homedir(), '.binance-agent', 'agent.pid');

// ========== CLI 命令 ==========

export async function start(opts = {}) {
  const config = getConfig();
  if (!config?.apiKey) {
    console.error('❌ Not logged in. Run: binance-agent login --key sk-xxxxx');
    process.exit(1);
  }

  if (opts.daemon) {
    // 后台运行
    runAsDaemon();
    return;
  }

  console.log('🤖 Binance Square Agent starting...');
  console.log(`   User: ${config.userId}`);
  console.log(`   Server: ${config.serverUrl}`);
  console.log(`   Polling every ${POLL_INTERVAL / 1000}s`);
  console.log('');
  console.log('Press Ctrl+C to stop');
  console.log('─'.repeat(50));

  // 写PID文件
  fs.writeFileSync(PID_FILE, process.pid.toString());

  // 检查依赖
  const deps = checkDependencies();
  if (!deps.ok) {
    console.error('❌ Missing dependencies:', deps.missing.join(', '));
    console.error('   Please install: ' + deps.hint);
    process.exit(1);
  }
  console.log('✅ Chrome: found');
  console.log('✅ Peekaboo: found');
  console.log('');

  // 主循环
  let pollCount = 0;
  while (true) {
    pollCount++;
    try {
      const task = await pollTask(config);
      if (task) {
        console.log(`\n[${ts()}] 📋 Task #${task.id}: ${task.type}`);
        let result;
        try {
          result = await executeTask(task);
        } catch(e) {
          console.error(`[${ts()}] ❌ executeTask crashed: ${e.message}\n${e.stack}`);
          result = { success: false, error: e.message, steps: [] };
        }
        await reportResult(config, task.id, result);
        
        const status = result.success ? '✅' : '❌';
        console.log(`   ${status} ${result.success ? 'Success' : 'Failed: ' + result.error} (${result.duration_ms || 0}ms)`);
        
        // 写日志
        writeLog(task, result);
      } else {
        // 没任务，静默
        if (pollCount % 20 === 0) { // 每10分钟打印一次心跳
          console.log(`[${ts()}] 💓 idle (${pollCount} polls)`);
        }
      }
    } catch (e) {
      console.error(`[${ts()}] ⚠️ Error: ${e.message}`);
    }

    await new Promise(r => setTimeout(r, POLL_INTERVAL));
  }
}

export async function status() {
  const config = getConfig();
  if (!config) {
    console.log('❌ Not configured. Run: binance-agent login --key sk-xxxxx');
    return;
  }

  console.log('📊 Agent Status');
  console.log('─'.repeat(30));
  console.log(`  User:    ${config.userId}`);
  console.log(`  Plan:    ${config.plan}`);
  console.log(`  Server:  ${config.serverUrl}`);
  console.log(`  Logged:  ${config.loggedInAt}`);

  // 检查PID
  try {
    const pid = parseInt(fs.readFileSync(PID_FILE, 'utf8'));
    process.kill(pid, 0); // 检查进程是否存在
    console.log(`  Agent:   🟢 Running (PID ${pid})`);
  } catch {
    console.log(`  Agent:   ⚪ Stopped`);
  }

  // 依赖检查
  const deps = checkDependencies();
  console.log(`  Chrome:  ${deps.chrome ? '✅' : '❌'}`);
  console.log(`  Peekaboo: ${deps.peekaboo ? '✅' : '❌'}`);
}

export async function stop() {
  try {
    const pid = parseInt(fs.readFileSync(PID_FILE, 'utf8'));
    process.kill(pid, 'SIGTERM');
    fs.unlinkSync(PID_FILE);
    console.log('✅ Agent stopped');
  } catch {
    console.log('⚠️ Agent is not running');
  }
}

// ========== 核心逻辑 ==========

async function pollTask(config) {
  const result = await httpGet(`/api/agent/poll`, config.serverUrl);
  console.log(`[DEBUG poll] ok=${result.ok} data=${(result.data||'').substring(0,80)} err=${result.error||'none'}`);
  if (!result.ok) return null;
  
  try {
    const data = JSON.parse(result.data);
    return data.task || null; // { id, type, ...params }
  } catch {
    return null;
  }
}

async function executeTask(task) {
  switch (task.type) {
    case 'post':
      return publishPost(task);
    case 'poll':
      return publishPoll(task);
    case 'comment':
      return publishComment(task);
    case 'stats':
      return getStats(task.range || '7days');
    default:
      return { success: false, error: `unknown_task_type: ${task.type}` };
  }
}

async function reportResult(config, taskId, result) {
  await httpPost('/api/agent/report', {
    task_id: taskId,
    success: result.success,
    error: result.error || null,
    steps: result.steps || [],
    duration_ms: result.duration_ms || 0
  });
}

// ========== Helpers ==========

function checkDependencies() {
  let chrome = false, peekaboo = false;
  const missing = [];
  
  try {
    const r = run('osascript -e \'tell application "Google Chrome" to return name\'');
    chrome = r.ok;
  } catch {}
  
  try {
    const r = run('which peekaboo');
    peekaboo = r.ok;
  } catch {}

  if (!chrome) missing.push('Google Chrome');
  if (!peekaboo) missing.push('Peekaboo (npm install -g peekaboo)');

  return {
    ok: chrome && peekaboo,
    chrome,
    peekaboo,
    missing,
    hint: missing.join(' && ')
  };
}

function run(cmd) {
  try {
    return { ok: true, data: execSync(cmd, { timeout: 5000 }).toString().trim() };
  } catch {
    return { ok: false };
  }
}

function ts() {
  return new Date().toLocaleString('zh-CN', { hour12: false });
}

function writeLog(task, result) {
  if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });
  const logFile = path.join(LOG_DIR, `${new Date().toISOString().split('T')[0]}.jsonl`);
  const entry = {
    ts: new Date().toISOString(),
    task_id: task.id,
    type: task.type,
    success: result.success,
    error: result.error,
    duration_ms: result.duration_ms,
    steps: result.steps?.length || 0
  };
  fs.appendFileSync(logFile, JSON.stringify(entry) + '\n');
}

function runAsDaemon() {
  const child = spawn(process.execPath, [process.argv[1], 'start'], {
    detached: true,
    stdio: 'ignore'
  });
  child.unref();
  fs.writeFileSync(PID_FILE, child.pid.toString());
  console.log(`✅ Agent started in background (PID ${child.pid})`);
  console.log('   Use `binance-agent stop` to stop');
  console.log('   Use `binance-agent status` to check');
}
